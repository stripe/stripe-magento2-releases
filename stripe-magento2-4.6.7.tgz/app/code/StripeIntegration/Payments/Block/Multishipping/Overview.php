<?php

namespace StripeIntegration\Payments\Block\Multishipping;

class Overview extends \Magento\Framework\View\Element\Template
{
    private $initParams;
    private $multishippingQuoteFactory;
    private $helper;
    private $quoteHelper;
    private $checkoutSession;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \StripeIntegration\Payments\Helper\Generic $helper,
        \StripeIntegration\Payments\Helper\Quote $quoteHelper,
        \StripeIntegration\Payments\Helper\InitParams $initParams,
        \StripeIntegration\Payments\Model\Multishipping\QuoteFactory $multishippingQuoteFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->quoteHelper = $quoteHelper;
        $this->initParams = $initParams;
        $this->multishippingQuoteFactory = $multishippingQuoteFactory;
        $this->checkoutSession = $checkoutSession;

        parent::__construct($context, $data);
    }

    public function willPayWithStripe()
    {
        $quote = $this->quoteHelper->getQuote();
        $paymentMethod = $quote->getPayment()->getMethod();
        return (strpos($paymentMethod, "stripe_") === 0);
    }

    public function getStoreCode()
    {
        $store = $this->helper->getCurrentStore();
        return $store->getCode();
    }

    public function getStripeParams()
    {
        return json_decode(json_encode($this->initParams->getMultishippingParams()));
    }

    public function hasPaymentMethod()
    {
        $quote = $this->quoteHelper->getQuote();
        if (empty($quote))
            return false;

        $model = $this->multishippingQuoteFactory->create();
        $model->load($quote->getId(), 'quote_id');

        if (empty($model->getPaymentMethodId()) && empty($model->getConfirmationToken()))
        {
            $this->helper->addWarning(__("Please specify a payment method."));
            return "false";
        }

        // When there are orders already placed, and we come back to the overview page,
        // it means we reached this page only by typing the URL in the browser.
        // To have a normal working flow, we would need a new confirmation token, therefore we will
        // redirect the user to the billing page to select the payment method.
        if ($this->checkoutSession->getMultishippingOrdersPlaced())
        {
            $this->checkoutSession->unsMultishippingOrdersPlaced();
            $this->helper->addWarning(__("Please specify a payment method."));
            return "false";
        }

        return "true";
    }
}
