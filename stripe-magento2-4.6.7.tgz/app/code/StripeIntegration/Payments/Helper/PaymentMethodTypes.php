<?php

namespace StripeIntegration\Payments\Helper;

class PaymentMethodTypes
{
    private $quoteHelper;

    public function __construct(
        \StripeIntegration\Payments\Helper\Quote $quoteHelper
    ) {
        $this->quoteHelper = $quoteHelper;
    }

    // Kept in case an override is needed
    public function getPaymentMethodTypes()
    {
        $quote = $this->quoteHelper->getQuote();

        if (!$quote || !$quote->getId())
        {
            return null;
        }

        $totalAdjustment = floatval($quote->getRewardCurrencyAmount()) +
            floatval($quote->getGiftCardsAmountUsed()) +
            floatval($quote->getCustomerBalanceAmountUsed());

        if ($totalAdjustment > 0)
        {
            // Gift cards, store credit and reward points can only be applied once per order,
            // so we filter to synchronous payment methods only.
            return ['card'];
        }

        return null;
    }
}