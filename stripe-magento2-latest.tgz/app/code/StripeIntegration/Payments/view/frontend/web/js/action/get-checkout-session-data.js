/*global define*/
define(
    [
        'Magento_Checkout/js/model/url-builder',
        'mage/storage'
    ],
    function (urlBuilder, storage) {
        'use strict';

        return function (params)
        {
            var serviceUrl = urlBuilder.createUrl('/stripe/payments/checkout_session_data', {});

            return new Promise(function (resolve, reject) {
                storage.post(serviceUrl, JSON.stringify({ contact_details: params || null }))
                    .done(function (response) { resolve(response); })
                    .fail(function (jqXHR) { reject(jqXHR); });
            });
        };
    }
);
