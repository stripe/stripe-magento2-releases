/*global define*/
define(
    [
        'ko',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Magento_Checkout/js/action/place-order',
        'Magento_Checkout/js/model/payment/method-list',
        'Magento_Checkout/js/action/select-payment-method',
        'StripeIntegration_Payments/js/stripe',
        'StripeIntegration_Payments/js/action/get-checkout-session-data',
        'StripeIntegration_Payments/js/action/post-update-cart-wcs',
        'StripeIntegration_Payments/js/action/post-restore-quote',
        'Magento_CheckoutAgreements/js/model/agreement-validator',
        'uiRegistry',
        'Magento_Customer/js/customer-data',
        'StripeIntegration_Payments/js/helper/checkout-common',
        'mage/translate',
        'mage/url',
        'jquery'
    ],
    function (
        ko,
        Component,
        quote,
        additionalValidators,
        placeOrderAction,
        methodList,
        selectPaymentMethodAction,
        stripe,
        getCheckoutSessionData,
        updateCartAction,
        restoreQuoteAction,
        agreementValidator,
        registry,
        customerData,
        checkoutCommon,
        $t,
        urlBuilder,
        $
    ) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'StripeIntegration_Payments/payment/stripe_payments_wcs'
            },
            redirectAfterPlaceOrder: false,

            checkoutInstance: null,
            checkoutActions: null,
            paymentElement: null,
            currencySelector: null,
            currencySelectorMounted: false,
            selectedPaymentMethodCode: null,
            checkoutSessionId: null,
            clientSecret: null,
            isEmailRequired: false,
            generation: 0,
            debounceTimer: null,
            subscriptions: [],
            emailSubscription: null,

            initObservable: function ()
            {
                this._super()
                    .observe([
                        'isLoading',
                        'stripePaymentsError',
                        'permanentError',
                        'isOrderPlaced',
                        'isInitializing',
                        'isPlaceOrderActionAllowed',
                        'showCurrencySelector',
                        'selectedPaymentMethodCode',
                        'checkoutActions'
                    ]);

                this.isOrderPlaced(false);
                this.isInitializing(true);
                this.showCurrencySelector(false);

                this.isPlaceOrderEnabled = ko.computed(function ()
                {
                    if (this.stripePaymentsError())
                        return false;

                    if (this.permanentError())
                        return false;

                    if (!this.isPlaceOrderActionAllowed())
                        return false;

                    if (!quote.billingAddress())
                        return false;

                    if (!this.selectedPaymentMethodCode())
                        return false;

                    if (!this.checkoutActions())
                        return false;

                    return true;
                }, this);

                this.isBillingAddressSet = ko.computed(function () {
                    return !!quote.billingAddress();
                }, this);

                // ---------- Quote change subscriptions ----------

                var self = this;
                var currentTotals = quote.totals();

                this.subscriptions.push(quote.totals.subscribe(function (totals)
                {
                    if (!totals || !totals.grand_total || !totals.quote_currency_code)
                        return;

                    if (!currentTotals || !currentTotals.grand_total || !currentTotals.quote_currency_code)
                    {
                        currentTotals = totals;
                        return;
                    }

                    if (totals.grand_total === currentTotals.grand_total &&
                        totals.quote_currency_code === currentTotals.quote_currency_code)
                        return;

                    currentTotals = totals;
                    self.onQuoteDataChangedDebounced();
                }));

                var currentBillingAddress = quote.billingAddress();

                this.subscriptions.push(quote.billingAddress.subscribe(function (address)
                {
                    if (!currentBillingAddress)
                    {
                        currentBillingAddress = address;
                        return;
                    }

                    if (address && currentBillingAddress.getKey &&
                        address.getKey() === currentBillingAddress.getKey())
                        return;

                    currentBillingAddress = address;
                    self.updatePaymentElementDefaultValues();
                }));

                var currentShippingAddressKey = this.getShippingAddressKey(quote.shippingAddress());

                this.subscriptions.push(quote.shippingAddress.subscribe(function (address)
                {
                    var newKey = self.getShippingAddressKey(address);

                    if (newKey === currentShippingAddressKey)
                        return;

                    // Skip the first emission after a null address.
                    if (currentShippingAddressKey === null)
                    {
                        currentShippingAddressKey = newKey;
                        return;
                    }

                    currentShippingAddressKey = newKey;
                    self.onQuoteDataChangedDebounced();
                }));

                /* ---------- Email change subscription ---------- */

                var doUpdateEmail = function (newEmail)
                {
                    if (!newEmail)
                        return;

                    // Always queue a re-init when the email changes, even if the
                    // session hasn't been created yet.
                    self.onQuoteDataChangedDebounced();
                };

                // Shipping step email component (physical carts)
                registry.async('checkout.steps.shipping-step.shippingAddress.customer-email')(function (emailComponent)
                {
                    if (emailComponent && emailComponent.email &&
                        typeof emailComponent.email.subscribe === 'function')
                    {
                        self.emailSubscription = emailComponent.email.subscribe(doUpdateEmail);
                    }
                });

                // Billing step email component (virtual carts)
                registry.async('checkout.steps.billing-step.payment.customer-email')(function (emailComponent)
                {
                    if (emailComponent && emailComponent.email &&
                        typeof emailComponent.email.subscribe === 'function')
                    {
                        var sub = emailComponent.email.subscribe(doUpdateEmail);
                        self.subscriptions.push(sub);
                    }
                });

                if (customerData && customerData.email)
                {
                    doUpdateEmail(customerData.email);
                }

                return this;
            },

            /**
             * Component destroy: dispose subscriptions, timer, and Stripe elements.
             */
            destroy: function ()
            {
                if (this.emailSubscription)
                {
                    this.emailSubscription.dispose();
                    this.emailSubscription = null;
                }

                for (var i = 0; i < this.subscriptions.length; i++)
                {
                    if (this.subscriptions[i] && typeof this.subscriptions[i].dispose === 'function')
                    {
                        this.subscriptions[i].dispose();
                    }
                }
                this.subscriptions = [];

                if (this.debounceTimer)
                {
                    clearTimeout(this.debounceTimer);
                    this.debounceTimer = null;
                }

                this.destroyCheckoutElements();
                this._super();
            },


            /* ---------- Quote change handling ---------- */

            onQuoteDataChangedDebounced: function ()
            {
                var self = this;

                if (this.debounceTimer)
                {
                    clearTimeout(this.debounceTimer);
                }

                this.debounceTimer = setTimeout(function ()
                {
                    self.onQuoteDataChanged();
                }, 500);
            },

            onQuoteDataChanged: function ()
            {
                var self = this;
                this.generation++;
                var currentGen = this.generation;

                this.isLoading(true);
                this.destroyCheckoutElements();

                this.initCheckoutElements(function ()
                {
                    if (currentGen !== self.generation)
                    {
                        return;
                    }

                    self.isLoading(false);
                    self.isInitializing(false);
                });
            },

            /* ---------- Checkout Elements SDK lifecycle ---------- */

            destroyCheckoutElements: function ()
            {
                if (this.paymentElement)
                {
                    try
                    {
                        if (typeof this.paymentElement.destroy === 'function')
                        {
                            this.paymentElement.destroy();
                        }
                        else if (typeof this.paymentElement.unmount === 'function')
                        {
                            this.paymentElement.unmount();
                        }
                    }
                    catch (e)
                    {
                        console.warn('Error destroying payment element:', e);
                    }

                    this.paymentElement = null;
                }

                if (this.currencySelector)
                {
                    try
                    {
                        if (typeof this.currencySelector.destroy === 'function')
                        {
                            this.currencySelector.destroy();
                        }
                        else if (typeof this.currencySelector.unmount === 'function')
                        {
                            this.currencySelector.unmount();
                        }
                    }
                    catch (e)
                    {
                        console.warn('Error destroying currency selector:', e);
                    }

                    this.currencySelector = null;
                }

                this.checkoutActions(null);
                this.checkoutInstance = null;
                this.showCurrencySelector(false);
                this.currencySelectorMounted = false;
            },

            onContainerRendered: function ()
            {
                var self = this;

                // Bump generation so any in-flight callback from a prior
                // onQuoteDataChanged is recognized as stale.
                this.generation++;

                this.isInitializing(true);
                this.isLoading(true);

                stripe.initStripe(this.getInitParams(), function (err)
                {
                    if (err)
                    {
                        self.crash(err);
                        return;
                    }

                    self.initCheckoutElements(function ()
                    {
                        self.isInitializing(false);
                    });
                });
            },

            getInitParams: function ()
            {
                return window.checkoutConfig.payment.stripe_payments.initParams;
            },

            initCheckoutElements: function (callback)
            {
                var self = this;
                var currentGen = this.generation;

                // Wait for the billing address to be set before making the API
                // call so the full billing details (name, phone, address) can be
                // sent alongside the email and used for customer_details on the
                // session. Payment methods like ACH require billing_details[name].
                var billingAddress = quote.billingAddress();
                if (!billingAddress)
                {
                    var sub = quote.billingAddress.subscribe(function (addr) {
                        if (addr)
                        {
                            sub.dispose();
                            self.initCheckoutElements(callback);
                        }
                    });
                    return;
                }

                var params = {};

                var email = checkoutCommon.getBillingEmail();
                if (email)
                    params.email = email;

                if (billingAddress.telephone)
                    params.phoneNumber = billingAddress.telephone;

                var billingName = checkoutCommon.getNameFromAddress(billingAddress);
                if (billingName)
                {
                    params.billingAddress = { name: billingName };
                    var billingAddr = checkoutCommon.getStripeFormattedAddress(billingAddress);
                    if (billingAddr)
                    {
                        var clean = {};
                        ['line1', 'line2', 'city', 'state', 'country', 'postal_code'].forEach(function (k) {
                            if (billingAddr[k]) clean[k] = billingAddr[k];
                        });
                        if (Object.keys(clean).length)
                        {
                            if (!params.billingAddress) params.billingAddress = {};
                            params.billingAddress.address = clean;
                        }
                    }
                }

                var shippingAddress = quote.shippingAddress();
                if (shippingAddress && !quote.isVirtual() && shippingAddress.countryId)
                {
                    var shippingName = checkoutCommon.getNameFromAddress(shippingAddress);
                    if (shippingName)
                    {
                        params.shippingAddress = { name: shippingName };
                        var shippingAddr = checkoutCommon.getStripeFormattedAddress(shippingAddress);
                        if (shippingAddr)
                        {
                            var cleanShipping = {};
                            ['line1', 'line2', 'city', 'state', 'country', 'postal_code'].forEach(function (k) {
                                if (shippingAddr[k]) cleanShipping[k] = shippingAddr[k];
                            });
                            if (Object.keys(cleanShipping).length)
                            {
                                if (!params.shippingAddress) params.shippingAddress = {};
                                params.shippingAddress.address = cleanShipping;
                            }
                        }
                    }
                }

                getCheckoutSessionData(params).then(function (response)
                {
                    // Stale response guard
                    if (currentGen !== self.generation)
                    {
                        return;
                    }

                    try
                    {
                        var data = response;

                        if (typeof data === 'string')
                        {
                            data = JSON.parse(data);
                        }

                        if (data.error)
                        {
                            // The endpoint returns user-safe (localized) messages
                            self.crash(data.error, data.error);
                            return;
                        }

                        self.clientSecret = data.client_secret;
                        self.checkoutSessionId = data.session_id;
                        self.isEmailRequired = data.is_email_required === true;
                        self.isOrderPlaced(data.is_order_placed === true);

                        self.mountCheckoutElements(callback, currentGen);
                    }
                    catch (e)
                    {
                        if (currentGen === self.generation)
                        {
                            self.crash(e.message);
                        }
                    }
                }).catch(function (jqXHR)
                {
                    if (currentGen !== self.generation)
                    {
                        return;
                    }

                    var msg = 'Could not initialize Checkout Session.';

                    if (jqXHR.responseJSON && jqXHR.responseJSON.message)
                    {
                        msg = jqXHR.responseJSON.message;
                    }

                    self.crash(msg);
                });
            },

            mountCheckoutElements: function (callback, currentGen)
            {
                var self = this;

                if (!document.getElementById('stripe-payment-element'))
                {
                    return this.crash("Cannot initialize Payment Element on a DOM that does not contain a div#stripe-payment-element.");
                }

                if (!stripe.stripeJs)
                {
                    return this.crash("Stripe.js could not be initialized.");
                }

                var checkout = null;

                try
                {
                    checkout = stripe.stripeJs.initCheckoutElementsSdk({
                        clientSecret: this.clientSecret,
                        adaptivePricing: {
                            allowed: !!this.config().useAdaptivePricing
                        },
                        elementsOptions: this.getElementsOptions()
                    });
                }
                catch (e)
                {
                    this.crash(e.message);
                    return;
                }

                checkout.loadActions().then(function (result)
                {
                    // Stale response guard
                    if (currentGen !== self.generation)
                    {
                        return;
                    }

                    if (!result || result.type !== 'success' || !result.actions)
                    {
                        var errMsg = 'Failed to load Checkout Elements actions.';

                        if (result && result.error && result.error.message)
                        {
                            errMsg = result.error.message;
                        }

                        self.crash(errMsg);
                        return;
                    }

                    self.checkoutInstance = checkout;
                    self.checkoutActions(result.actions);

                    // Mount Currency Selector BEFORE Payment Element if session has options
                    var session = null;

                    try
                    {
                        session = self.checkoutActions().getSession();
                    }
                    catch (e)
                    {
                        // session format may vary; proceed without currency selector
                    }

                    if (session && session.currencyOptions && session.currencyOptions.length > 0)
                    {
                        // Make container visible before mount so Stripe iframe gets proper dimensions
                        self.showCurrencySelector(true);

                        try
                        {
                            self.currencySelector = self.checkoutInstance.createCurrencySelectorElement();
                            self.currencySelector.mount('#wcs-currency-selector');
                            self.currencySelectorMounted = true;
                        }
                        catch (e)
                        {
                            self.currencySelector = null;
                            self.showCurrencySelector(false);
                            console.warn('[Stripe][WCS] Could not mount currency selector:', e.message);
                        }
                    }
                    else
                    {
                        // Listen for late session updates that might add currency options
                        try
                        {
                            self.checkoutInstance.on('change', function ()
                            {
                                if (self.currencySelectorMounted)
                                {
                                    return;
                                }

                                var updatedSession = null;

                                try
                                {
                                    updatedSession = self.checkoutActions().getSession();
                                }
                                catch (e)
                                {
                                    return;
                                }

                                if (updatedSession && updatedSession.currencyOptions &&
                                    updatedSession.currencyOptions.length > 0)
                                {
                                    // Make container visible before mount
                                    self.showCurrencySelector(true);

                                    try
                                    {
                                        self.currencySelector = self.checkoutInstance.createCurrencySelectorElement();
                                        self.currencySelector.mount('#wcs-currency-selector');
                                        self.currencySelectorMounted = true;
                                    }
                                    catch (e)
                                    {
                                        self.currencySelector = null;
                                        self.showCurrencySelector(false);
                                        console.warn('[Stripe][WCS] Could not lazily mount currency selector:', e.message);
                                    }
                                }
                            });
                        }
                        catch (e)
                        {
                            // Instance change subscription may not be supported
                        }
                    }

                    // Mount Payment Element with shared options
                    try
                    {
                        self.paymentElement = self.checkoutInstance.createPaymentElement(
                            self.getWcsPaymentElementOptions()
                        );
                        self.paymentElement.mount('#stripe-payment-element');
                        self.paymentElement.on('change', self.onChange.bind(self));
                        self.paymentElement.on('loaderror', self.onLoadError.bind(self));
                        self.updatePaymentElementDefaultValues();
                    }
                    catch (e)
                    {
                        self.crash(e.message);
                        return;
                    }

                    self.isLoading(false);

                    if (callback)
                    {
                        callback();
                    }
                }).catch(function (error)
                {
                    if (currentGen === self.generation)
                    {
                        self.crash(error && error.message ? error.message : 'Failed to load Checkout Elements.');
                    }
                });
            },

            getElementsOptions: function ()
            {
                var raw = window.checkoutConfig.payment.stripe_payments.elementOptions;
                var options = raw ? Object.assign({}, raw) : {};

                return checkoutCommon.getCheckoutElementsOptions(options);
            },

            /* ---------- Payment Element events ---------- */

            getConfirmParams: function ()
            {
                var params = { redirect: 'if_required' };

                var billingAddress = quote.billingAddress();

                if (this.isEmailRequired)
                {
                    var email = checkoutCommon.getBillingEmail();
                    if (email)
                        params.email = email;
                }

                if (billingAddress)
                {
                    var name = checkoutCommon.getNameFromAddress(billingAddress);
                    if (name)
                        params.billingAddress = { name: name };

                    var address = checkoutCommon.getStripeFormattedAddress(billingAddress);
                    if (address && (address.line1 || address.city || address.country))
                    {
                        // Remove null fields — confirm params only wants present values
                        var clean = {};
                        ['line1', 'line2', 'city', 'state', 'country', 'postal_code'].forEach(function (k) {
                            if (address[k]) clean[k] = address[k];
                        });
                        if (!params.billingAddress)
                            params.billingAddress = {};
                        params.billingAddress.address = clean;
                    }
                }

                var shippingAddress = quote.shippingAddress();
                if (shippingAddress && !quote.isVirtual() && shippingAddress.countryId)
                {
                    params.shippingAddress = {};
                    var shippingName = checkoutCommon.getNameFromAddress(shippingAddress);
                    if (shippingName)
                        params.shippingAddress.name = shippingName;

                    var shippingAddr = checkoutCommon.getStripeFormattedAddress(shippingAddress);
                    if (shippingAddr)
                    {
                        var cleanShipping = {};
                        ['line1', 'line2', 'city', 'state', 'country', 'postal_code'].forEach(function (k) {
                            if (shippingAddr[k]) cleanShipping[k] = shippingAddr[k];
                        });
                        if (Object.keys(cleanShipping).length)
                            params.shippingAddress.address = cleanShipping;
                    }

                    if (!params.shippingAddress.name && !params.shippingAddress.address)
                        delete params.shippingAddress;
                }

                return params;
            },



            onChange: function (event)
            {
                this.isLoading(false);

                if (event.value && event.value.type)
                {
                    this.selectedPaymentMethodCode(event.value.type);
                }
                else
                {
                    this.selectedPaymentMethodCode(null);
                }
            },

            onLoadError: function (event)
            {
                if (event && event.error && event.error.message)
                {
                    if (event.error.message.indexOf("No valid payment method types") >= 0)
                    {
                        this.disablePaymentMethod();
                        console.warn("[Stripe][WCS] " + event.error.message);
                    }
                    else
                    {
                        this.permanentError(event.error.message);
                    }
                }
                else
                {
                    this.crash(event);
                }
            },

            disablePaymentMethod: function ()
            {
                var methodCode = this.getCode();

                if (quote.paymentMethod() && quote.paymentMethod().method === methodCode)
                {
                    selectPaymentMethodAction(null);
                }

                methodList.remove(function (method)
                {
                    return method.method === methodCode;
                });
            },

            /* ---------- Place order ---------- */

            placeOrder: function ()
            {
                this.messageContainer.clear();

                if (!this.validate())
                    return;

                this.clearErrors();
                this.isPlaceOrderActionAllowed(false);
                this.isLoading(true);

                var self = this;

                if (this.isOrderPlaced())
                {
                    // Recovery path: order was already placed on a previous attempt
                    // (back button from 3DS / external payment page, or page refresh
                    // after order placement and before payment confirmation).
                    updateCartAction(this.getData(), function (result, outcome, response)
                    {
                        self.onCartUpdated(result, outcome, response);
                    });

                    return false;
                }

                // Validate the Payment Element before proceeding
                if (this.checkoutActions() &&
                    typeof this.checkoutActions().validateElements === 'function')
                {
                    var validationResult = this.checkoutActions().validateElements();
                    if (validationResult && validationResult.valid === false)
                    {
                        this.isLoading(false);
                        this.isPlaceOrderActionAllowed(true);
                        return false;
                    }
                }

                var manualAuthMethods = window.checkoutConfig.payment.stripe_payments.manualAuthenticationMethods || [];
                var requiresConfirmFirst = manualAuthMethods.indexOf(this.selectedPaymentMethodCode()) >= 0;

                // In the WCS flow, payment confirmation always happens client-side.
                // Manual-auth methods (e.g. cards requiring 3DS) must confirm FIRST so that
                // any authentication challenges are resolved before the Magento order is placed.
                // Standard methods place the order first, then confirm — the order starts as
                // pending and is updated to processing when the payment completes.
                if (requiresConfirmFirst)
                {
                    this.confirmThenPlaceOrder();
                }
                else
                {
                    this.placeOrderThenConfirm();
                }

                return false;
            },

            /* ---------- Shared: WCS payment confirmation ---------- */

            confirmPayment: function ()
            {
                if (!this.checkoutActions())
                {
                    this.showError("Checkout session is not available.");
                    return;
                }

                var self = this;

                try
                {
                    // Invalidate the cached cart before confirming: redirect-based payment methods
                    // navigate the browser away when confirm() redirects, so the code after this
                    // call never runs. The order has already been placed at this point, so the
                    // cached cart would otherwise still show the items.
                    customerData.invalidate(['cart']);

                    this.checkoutActions().confirm(this.getConfirmParams())
                    .then(function (result)
                    {
                        // If the browser redirected, this code does not run.
                        // A resolved promise means no redirect occurred.

                        if (result && (result.error || (result.errors && result.errors.length)))
                        {
                            restoreQuoteAction();
                            var errMsg = result.error ?
                                result.error.message :
                                result.errors[0].message;

                            self.showError(errMsg);
                            self.isLoading(false);
                            self.isPlaceOrderActionAllowed(true);
                            return;
                        }

                        // No redirect, no error - confirm succeeded.
                        customerData.invalidate(['cart']);
                        var returnUrl = self.getWcsReturnUrl();

                        if (returnUrl)
                        {
                            $.mage.redirect(returnUrl);
                        }
                    }).catch(function (error)
                    {
                        restoreQuoteAction();
                        self.showError(error && error.message ? error.message : "Payment confirmation failed.");
                        self.isLoading(false);
                        self.isPlaceOrderActionAllowed(true);
                    });
                }
                catch (e)
                {
                    restoreQuoteAction();
                    self.showError(e && e.message ? e.message : "Payment confirmation failed.");
                    self.isLoading(false);
                    self.isPlaceOrderActionAllowed(true);
                }
            },

            /* ---------- Standard methods: place order, then confirm ---------- */

            placeOrderThenConfirm: function ()
            {
                var self = this;

                this.isLoading(false); // Needed for terms and conditions checkbox
                this.getPlaceOrderDeferredObject()
                    .fail(function (response)
                    {
                        self.isLoading(false);
                        self.isPlaceOrderActionAllowed(true);

                        if (response && response.responseJSON && response.responseJSON.message)
                        {
                            self.showError(response.responseJSON.message);
                        }
                        else
                        {
                            self.showError($t("The order could not be placed. Please contact us for assistance."));
                        }

                        if (response && response.responseText)
                            console.error(response.responseText);
                    })
                    .done(function ()
                    {
                        self.isOrderPlaced(true);

                        // Now confirm the WCS payment — redirects on success.
                        self.confirmPayment();
                    })
                    .always(function (response, status)
                    {
                        if (status !== "success")
                        {
                            if (response && response.responseText)
                                console.error('[Stripe][WCS] placeOrderThenConfirm always: ' + response.responseText);
                            self.isLoading(false);
                            self.isPlaceOrderActionAllowed(true);
                        }
                    });
            },

            /* ---------- Manual-auth methods: confirm, then place order ---------- */

            confirmThenPlaceOrder: function ()
            {
                var self = this;

                if (!this.checkoutActions())
                {
                    this.showError("Checkout session is not available.");
                    return;
                }

                try
                {
                    this.checkoutActions().confirm(this.getConfirmParams())
                    .then(function (result)
                    {
                        // A resolved promise means no redirect occurred.

                        if (result && (result.error || (result.errors && result.errors.length)))
                        {
                            var errMsg = result.error ?
                                result.error.message :
                                result.errors[0].message;

                            self.showError(errMsg);
                            self.isLoading(false);
                            self.isPlaceOrderActionAllowed(true);
                            return;
                        }

                        // No redirect, no error — place the Magento order now.
                        self.placeOrderAfterConfirm();
                    }).catch(function (error)
                    {
                        self.showError(error && error.message ? error.message : "Payment confirmation failed.");
                        self.isLoading(false);
                        self.isPlaceOrderActionAllowed(true);
                    });
                }
                catch (e)
                {
                    self.showError(e && e.message ? e.message : "Payment confirmation failed.");
                    self.isLoading(false);
                    self.isPlaceOrderActionAllowed(true);
                }
            },

            placeOrderAfterConfirm: function ()
            {
                var self = this;

                this.isLoading(false); // Needed for terms and conditions checkbox
                this.getPlaceOrderDeferredObject()
                    .fail(function (response)
                    {
                        self.isLoading(false);
                        self.isPlaceOrderActionAllowed(true);

                        if (response && response.responseJSON && response.responseJSON.message)
                        {
                            self.showError(response.responseJSON.message);
                        }
                        else
                        {
                            self.showError($t("The order could not be placed. Please contact us for assistance."));
                        }

                        if (response && response.responseText)
                            console.error(response.responseText);
                    })
                    .done(function ()
                    {
                        self.isOrderPlaced(true);
                        customerData.invalidate(['cart']);
                        var returnUrl = self.getWcsReturnUrl();

                        if (returnUrl)
                        {
                            $.mage.redirect(returnUrl);
                        }
                    })
                    .always(function (response, status)
                    {
                        if (status !== "success")
                        {
                            if (response && response.responseText)
                                console.error('[Stripe][WCS] placeOrderAfterConfirm always: ' + response.responseText);
                            self.isLoading(false);
                        }
                    });
            },

            /* ---------- Update-cart recovery (order-first) ---------- */

            onCartUpdated: function (result, outcome, response)
            {
                var self = this;

                try
                {
                    var data = typeof result === 'string' ? JSON.parse(result) : result;

                    if (data.error)
                    {
                        this.showError(data.error);
                    }
                    else if (data.redirect)
                    {
                        $.mage.redirect(data.redirect);
                    }
                    else if (data.placeNewOrder)
                    {
                        // Server says to place a fresh order
                        this.isLoading(true);
                        this.placeOrderThenConfirm();
                    }
                    else
                    {
                        // Order is already done - confirm and complete
                        this.isOrderPlaced(true);
                        this.isLoading(true);
                        this.confirmPayment();
                    }
                }
                catch (e)
                {
                    this.showError($t("The order could not be placed. Please contact us for assistance."));
                    console.error(e.message);
                }
            },

            /* ---------- Helpers ---------- */

            // Shared via checkout-common
            getStripeParam: function (param)
            {
                return checkoutCommon.getStripeParam(param);
            },

            /**
             * Builds options for createPaymentElement specific to the WCS flow.
             * Passes only the fields config and defaultValues — omits wallets,
             * layout, terms etc. that the Checkout Elements SDK rejects.
             */
            getWcsPaymentElementOptions: function ()
            {
                var options = {};

                // Appearance options from config (wallets, layout, terms, etc.)
                var params = window.checkoutConfig.payment.stripe_payments &&
                    window.checkoutConfig.payment.stripe_payments.initParams;
                if (params)
                {
                    if (params.wallets)
                        options.wallets = params.wallets;
                    if (params.layout)
                        options.layout = params.layout;
                    if (params.terms)
                        options.terms = params.terms;
                }

                // Fields config — marks billing fields that the merchant provides
                // as 'never' so Stripe doesn't render its own inputs for them.
                options.fields = {
                    billingDetails: {
                        name: 'never',
                        email: 'never',
                        phone: 'never',
                        address: 'never'
                    }
                };

                return options;
            },

            updatePaymentElementDefaultValues: function ()
            {
                if (!this.paymentElement || typeof this.paymentElement.update !== 'function')
                    return;

                var billingDetails = checkoutCommon.getBillingDetails();
                if (!billingDetails)
                    return;

                this.paymentElement.update({
                    defaultValues: { billingDetails: billingDetails }
                });
            },

            getPlaceOrderDeferredObject: function ()
            {
                return placeOrderAction(this.getData(), this.messageContainer);
            },

            getData: function ()
            {
                var data = {
                    'method': this.item.method,
                    'additional_data': {}
                };

                if (this.checkoutSessionId)
                {
                    data.additional_data.checkout_session_id = this.checkoutSessionId;
                }

                return data;
            },

            /**
             * Build a stable signature of the shipping address content so that any change
             * (including in-place edits that keep the same address ID) can be detected and
             * the Checkout Session invalidated + re-created.
             */
            getShippingAddressKey: function (address)
            {
                if (!address)
                    return null;

                var street = address.street;
                if (Array.isArray(street))
                    street = street.join('\n');

                return [
                    address.firstname,
                    address.middlename,
                    address.lastname,
                    address.company,
                    street,
                    address.city,
                    address.regionCode,
                    address.region,
                    address.regionId,
                    address.postcode,
                    address.countryId,
                    address.telephone
                ].join('|');
            },

            getWcsReturnUrl: function ()
            {
                // Build WCS completion URL with checkout_session_id for immediate (non-redirect) flow
                var base = urlBuilder.build('stripe/payment/index');
                var params = 'payment_method=stripe_payments_wcs';

                if (this.checkoutSessionId)
                {
                    params += '&checkout_session_id=' + encodeURIComponent(this.checkoutSessionId);
                }

                return base + (base.indexOf('?') >= 0 ? '&' : '?') + params;
            },

            validate: function ()
            {
                return agreementValidator.validate() && additionalValidators.validate();
            },

            getCode: function ()
            {
                return 'stripe_payments';
            },

            clearErrors: function ()
            {
                this.stripePaymentsError(null);
            },

            showError: function (message)
            {
                this.isLoading(false);
                this.isPlaceOrderActionAllowed(true);
                this.messageContainer.addErrorMessage({ "message": message });
            },

            crash: function (message, displayMessage)
            {
                this.isLoading(false);
                var userError = this.getStripeParam("userError");

                if (userError)
                    this.permanentError(userError);
                else if (displayMessage)
                    this.permanentError(displayMessage);
                else
                    this.permanentError($t("Sorry, this payment method is not available. Please contact us for assistance."));

                console.error("Error: ", message);
            },

            config: function ()
            {
                return window.checkoutConfig.payment[this.getCode()];
            },

            isActive: function (parents)
            {
                var config = this.config();
                return config && config.usePaymentElementWithCheckoutSessions;
            },

            isCollapsed: function ()
            {
                if (this.isChecked() === this.getCode())
                {
                    return false;
                }

                return true;
            }
        });
    }
);
