define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list',
        'StripeIntegration_Payments/js/helper/subscriptions'
    ],
    function (
        Component,
        rendererList,
        subscriptions
    ) {
        'use strict';

        var subscriptionUpdateComponent = null;
        if (subscriptions.isSubscriptionUpdate())
        {
            subscriptionUpdateComponent = 'StripeIntegration_Payments/js/view/subscription_update/review';
        }

        var confirmationTokensRenderer = 'StripeIntegration_Payments/js/view/payment/method-renderer/stripe_payments';
        var checkoutSessionsRenderer = 'StripeIntegration_Payments/js/view/payment/method-renderer/stripe_payments_wcs';
        var useWcs = window.checkoutConfig.payment.stripe_payments &&
            window.checkoutConfig.payment.stripe_payments.usePaymentElementWithCheckoutSessions === true;

        rendererList.push(
            {
                type: 'stripe_payments',
                component: subscriptionUpdateComponent || (useWcs ? checkoutSessionsRenderer : confirmationTokensRenderer)
            },
            {
                type: 'stripe_payments_checkout',
                component: subscriptionUpdateComponent || 'StripeIntegration_Payments/js/view/payment/method-renderer/checkout'
            },
            {
                type: 'stripe_payments_bank_transfers',
                component: subscriptionUpdateComponent || 'StripeIntegration_Payments/js/view/payment/method-renderer/bank_transfers'
            }
        );

        // Add view logic here if needed
        return Component.extend({});
    }
);
