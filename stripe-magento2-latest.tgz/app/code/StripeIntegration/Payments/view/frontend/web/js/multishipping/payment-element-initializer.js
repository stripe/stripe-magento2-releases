define([
    'uiLayout',
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/action/select-payment-method',
    'StripeIntegration_Payments/js/multishipping/expand-payment-method'
], function (layout, $, quote, selectPaymentMethodAction, paymentMethod) {
    'use strict';

    var STRIPE_CODE = 'stripe_payments';

    /**
     * Selects the given payment method in the quote and expands its form.
     *
     * @param {String} method
     * @returns {void}
     */
    function selectPaymentMethod(method) {
        if (!quote.paymentMethod() || quote.paymentMethod().method !== method) {
            selectPaymentMethodAction({ method: method });
        }

        paymentMethod.expand(method);
    }

    /**
     * Keeps the quote's selected payment method in sync with the Stripe radio and expands the
     * payment method form. Setting the quote payment method prevents the Knockout "checked"
     * binding from resetting the radio if the click is handled before the bindings are applied.
     *
     * @returns {void}
     */
    function selectStripePaymentMethod() {
        if (!paymentMethod.isSelected(STRIPE_CODE)) {
            return;
        }

        selectPaymentMethod(STRIPE_CODE);
    }

    /**
     * Re-applies a payment method that was selected server side. The shared "isChecked" Knockout
     * computed is empty on page load, so the "checked" binding of the payment method components
     * resets a server rendered selection. Restoring it here keeps the customer's choice.
     *
     * @returns {Boolean}
     */
    function restoreServerSelectedPaymentMethod() {
        var $selected = $('#payment-methods input[name="payment[method]"][checked]'),
            method;

        if (!$selected.length) {
            return false;
        }

        method = $selected.val();

        if (!method) {
            return false;
        }

        selectPaymentMethod(method);

        return true;
    }

    /**
     * Selects and expands the Stripe payment method when no other payment method has been chosen,
     * so the payment element is immediately available without depending on a click.
     *
     * @returns {void}
     */
    function autoSelectStripePaymentMethod() {
        var $radio = paymentMethod.getRadio(STRIPE_CODE);

        if (!$radio.length || $radio.is(':checked') || $radio.is(':disabled')) {
            return;
        }

        $radio.trigger('click');
    }

    return function (config, element) {
        // Store the init parameters globally for the payment element component to access
        window.initParams = config.initParams;

        // Initialize the UI layout for the payment element
        layout([
            {
                component: 'StripeIntegration_Payments/js/view/multishipping/method-renderer/payment_element',
                name: 'payment_method_stripe_payments',
                method: STRIPE_CODE,
                item: {
                    method: STRIPE_CODE
                },
                captureMethod: config.captureMethod
            }
        ]);

        // Expand/select the payment method as early as the initializer runs. This does not depend
        // on Magento_Multishipping/js/payment.js or on the Knockout bindings being initialized.
        paymentMethod.getRadio(STRIPE_CODE).on('click change', selectStripePaymentMethod);

        if (!restoreServerSelectedPaymentMethod()) {
            // No payment method was selected, so default to Stripe.
            selectStripePaymentMethod();
            autoSelectStripePaymentMethod();
        }
    };
});
