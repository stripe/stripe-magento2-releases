/*global define*/
define(
    [
        'Magento_Checkout/js/model/quote'
    ],
    function (quote) {
        'use strict';

        return {
            zeroDecimalCurrencies: ['BIF','CLP','DJF','GNF','JPY','KMF','KRW','MGA','PYG','RWF','VND','VUV','XAF','XOF','XPF'],
            threeDecimalCurrencies: ['BHD','JOD','KWD','OMR','TND'],

            getAddressField: function (field)
            {
                if (!quote.billingAddress())
                    return null;

                var address = quote.billingAddress();

                if (!address[field] || address[field].length == 0)
                    return null;

                return address[field];
            },

            getBillingEmail: function ()
            {
                if (quote.guestEmail)
                {
                    return quote.guestEmail;
                }
                else if (window.checkoutConfig.customerData && window.checkoutConfig.customerData.email)
                {
                    return window.checkoutConfig.customerData.email;
                }

                return null;
            },

            // Normalize email for comparison (trim + lowercase).
            normalizeEmail: function (email)
            {
                if (!email)
                {
                    return '';
                }

                return email.trim().toLowerCase();
            },

            getBillingPhone: function ()
            {
                var billingAddress = quote.billingAddress();

                if (!billingAddress)
                    return null;

                if (billingAddress.telephone)
                    return billingAddress.telephone;

                return null;
            },

            getNameFromAddress: function (address)
            {
                if (!address)
                    return null;

                var parts = [];

                if (address.firstname)
                    parts.push(address.firstname);

                if (address.middlename)
                    parts.push(address.middlename);

                if (address.lastname)
                    parts.push(address.lastname);

                return parts.join(" ");
            },

            getStripeFormattedAddress: function (address)
            {
                var stripeAddress = {};

                if (address.regionCode)
                    stripeAddress.state = address.regionCode;
                else
                    stripeAddress.state = address.region ? address.region : null;

                stripeAddress.postal_code = address.postcode ? address.postcode : null;
                stripeAddress.country = address.countryId ? address.countryId : null;
                stripeAddress.city = address.city ? address.city : null;

                if (address.street && address.street.length > 0)
                {
                    stripeAddress.line1 = address.street[0];

                    if (address.street.length > 1)
                    {
                        stripeAddress.line2 = address.street[1];
                    }
                    else
                    {
                        stripeAddress.line2 = null;
                    }
                }
                else
                {
                    stripeAddress.line1 = null;
                    stripeAddress.line2 = null;
                }

                return stripeAddress;
            },

            getBillingDetails: function ()
            {
                var billingAddress = quote.billingAddress();
                if (!billingAddress)
                    return null;

                var details = {};

                var address = this.getStripeFormattedAddress(billingAddress);
                var clean = {};
                ['line1', 'line2', 'city', 'state', 'country', 'postal_code'].forEach(function (k) {
                    if (address && address[k]) clean[k] = address[k];
                });
                if (Object.keys(clean).length)
                    details.address = clean;

                var phone = this.getBillingPhone();
                if (phone)
                    details.phone = phone;

                var name = this.getNameFromAddress(billingAddress);
                if (name)
                    details.name = name;

                var email = this.getBillingEmail();
                if (email)
                    details.email = email;

                return Object.keys(details).length > 0 ? details : null;
            },

            hasShipping: function ()
            {
                return (quote && quote.shippingMethod() && quote.shippingMethod().method_code);
            },

            convertToStripeAmount: function (amount, currencyCode)
            {
                var code = currencyCode.toUpperCase();

                if (this.zeroDecimalCurrencies.indexOf(code) >= 0)
                {
                    return Math.round(amount);
                }
                else if (this.threeDecimalCurrencies.indexOf(code) >= 0)
                {
                    return Math.round(amount * 100) * 10;
                }
                else
                {
                    return Math.round(amount * 100);
                }
            },

            getElementsCurrency: function ()
            {
                var totals = quote.totals();

                if (totals && totals.quote_currency_code)
                {
                    var currency = totals.quote_currency_code;
                    return currency.toLowerCase();
                }

                return 'USD';
            },

            getClientSecretFromResponse: function (response)
            {
                if (typeof response != "string")
                {
                    return null;
                }

                if (response.indexOf("Authentication Required: ") >= 0)
                {
                    return response.substring("Authentication Required: ".length);
                }

                return null;
            },

            isInstallmentsSelection: function (response)
            {
                return response.indexOf("Select Installments") >= 0;
            },

            getStripeParam: function (param)
            {
                var initParams = window.checkoutConfig.payment.stripe_payments &&
                    window.checkoutConfig.payment.stripe_payments.initParams;

                if (!initParams)
                    return null;

                if (typeof initParams[param] !== "undefined")
                    return initParams[param];

                return null;
            },

            /**
             * Builds Payment Element creation options from current quote billing
             * address and init params. Designed to be called by both legacy and
             * wCS renderers via delegation.
             *
             * The fields.billingDetails values are 'never' for populated fields
             * (so Stripe does not render its own inputs) and 'auto' for missing
             * fields (Stripe collects them inline). When includeDefaults is true
             * (legacy flow) the current quote billing details are passed as
             * defaultValues.billingDetails. When false (WCS flow) defaultValues
             * is omitted because the Checkout Session owns customer data.
             *
             * @param {boolean} includeDefaults - true adds defaultValues.billingDetails
             * @return {Object} Options suitable for elements.create('payment', ...)
             *     or checkoutInstance.createPaymentElement(...)
             */
            getPaymentElementOptions: function (includeDefaults)
            {
                if (includeDefaults === undefined)
                    includeDefaults = true;

                var options = {};
                var params = window.checkoutConfig.payment.stripe_payments &&
                    window.checkoutConfig.payment.stripe_payments.initParams;

                if (params)
                {
                    if (params.wallets)
                        options.wallets = params.wallets;

                    if (params.layout)
                        options.layout = params.layout;

                    if (params.terms)
                        options.terms = params.terms;
                }

                var billingAddress = quote.billingAddress();

                if (billingAddress)
                {
                    try
                    {
                        var hasState = (billingAddress.region || billingAddress.regionCode || billingAddress.regionId);

                        options.fields = {
                            billingDetails: {
                                name: 'never',
                                email: 'never',
                                phone: 'never',
                                address: {
                                    line1: (billingAddress.street && billingAddress.street.length > 0) ? 'never' : 'auto',
                                    line2: (billingAddress.street && billingAddress.street.length > 0) ? 'never' : 'auto',
                                    city: billingAddress.city ? 'never' : 'auto',
                                    state: hasState ? 'never' : 'auto',
                                    country: billingAddress.countryId ? 'never' : 'auto',
                                    postalCode: billingAddress.postcode ? 'never' : 'auto'
                                }
                            }
                        };
                    }
                    catch (e)
                    {
                        options.fields = {};
                    }

                    if (includeDefaults)
                    {
                        var billingDetails = this.getBillingDetails();

                        if (billingDetails)
                        {
                            options.defaultValues = {
                                billingDetails: billingDetails
                            };
                        }
                    }
                }

                return options;
            },

            /**
             * Filters element options to only contain keys accepted by
             * initCheckoutElementsSdk.elementsOptions for Checkout Sessions.
             * Session-owned fields (mode, amount, currency, paymentMethodTypes,
             * paymentMethodConfiguration, customerSessionClientSecret,
             * paymentMethodOptions, externalPaymentMethods, wallets, locale)
             * are rejected. Only appearance, fonts, and loader may pass through.
             *
             * @param {Object} options - Raw element options from config
             * @return {Object} - Allowlisted options object
             */
            getCheckoutElementsOptions: function (options)
            {
                var allowed = ['appearance', 'fonts', 'loader'];
                var result = {};
                var key;

                for (key in options)
                {
                    if (options.hasOwnProperty(key) && allowed.indexOf(key) >= 0)
                    {
                        result[key] = options[key];
                    }
                }

                return result;
            }
        };
    }
);
