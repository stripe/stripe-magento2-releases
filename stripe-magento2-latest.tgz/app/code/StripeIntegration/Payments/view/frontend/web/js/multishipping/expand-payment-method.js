define([
    'jquery'
], function ($) {
    'use strict';

    var STRIPE_CODE = 'stripe_payments';

    return {
        /**
         * Returns the radio of the given payment method on the multi-shipping billing page.
         *
         * @param {String} [code]
         * @returns {jQuery}
         */
        getRadio: function (code) {
            return $('#p_method_' + (code || STRIPE_CODE));
        },

        /**
         * Checks whether the given payment method is currently selected.
         *
         * @param {String} [code]
         * @returns {Boolean}
         */
        isSelected: function (code) {
            return this.getRadio(code).is(':checked');
        },

        /**
         * Expands the <dd> of the given payment method on the multi-shipping billing page.
         *
         * The multi-shipping billing page normally expands the selected payment method via
         * Magento_Multishipping/js/payment.js. That widget, as well as the Knockout bindings of
         * the Stripe component, are initialized asynchronously, so a click can leave the radio
         * focused while the payment method stays collapsed. The module expands the method itself
         * so that the payment form is always visible once the method is selected.
         *
         * @param {String} [code]
         * @returns {Boolean}
         */
        expand: function (code) {
            var $radio = this.getRadio(code),
                $dd;

            if (!$radio.length) {
                return false;
            }

            $dd = $radio.closest('dt').next('dd');
            $dd.removeClass('no-display');
            $dd.find('.items').show();

            return true;
        }
    };
});
