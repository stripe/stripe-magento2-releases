<?php

namespace StripeIntegration\Payments\Helper\Stripe;

class CheckoutSession
{
    private $config;
    private $tokenHelper;
    private $cache;
    private $stripePaymentIntentFactory;
    private $stripeSetupIntentFactory;
    private $stripeSubscriptionFactory;
    private $invoicePaymentsHelper;

    public function __construct(
        \StripeIntegration\Payments\Model\Config $config,
        \StripeIntegration\Payments\Helper\Token $tokenHelper,
        \Magento\Framework\App\CacheInterface $cache,
        \StripeIntegration\Payments\Model\Stripe\PaymentIntentFactory $stripePaymentIntentFactory,
        \StripeIntegration\Payments\Model\Stripe\SetupIntentFactory $stripeSetupIntentFactory,
        \StripeIntegration\Payments\Model\Stripe\SubscriptionFactory $stripeSubscriptionFactory,
        InvoicePayments $invoicePaymentsHelper
    )
    {
        $this->config = $config;
        $this->tokenHelper = $tokenHelper;
        $this->cache = $cache;
        $this->stripePaymentIntentFactory = $stripePaymentIntentFactory;
        $this->stripeSetupIntentFactory = $stripeSetupIntentFactory;
        $this->stripeSubscriptionFactory = $stripeSubscriptionFactory;
        $this->invoicePaymentsHelper = $invoicePaymentsHelper;
    }

    public function getStoredFingerprint(string $sessionId): ?string
    {
        $cacheKey = 'stripe_session_' . $sessionId;
        $cached = $this->cache->load($cacheKey);
        if (!$cached) {
            return null;
        }
        $data = json_decode($cached, true);
        return $data['fingerprint'] ?? null;
    }

    public function saveStoredFingerprint(string $sessionId, string $fingerprint, ?string $contactHash = null, ?string $quoteFingerprint = null, ?array $quoteFingerprintData = null): void
    {
        $cacheKey = 'stripe_session_' . $sessionId;
        $cacheData = ['fingerprint' => $fingerprint];
        if ($contactHash) {
            $cacheData['contact_hash'] = $contactHash;
        }
        if ($quoteFingerprint) {
            $cacheData['quote_fingerprint'] = $quoteFingerprint;
        }
        if ($quoteFingerprintData) {
            $cacheData['quote_fingerprint_data'] = $quoteFingerprintData;
        }
        $this->cache->save(json_encode($cacheData), $cacheKey, ['stripe'], 3600);
    }

    public function getStoredQuoteFingerprint(string $sessionId): ?string
    {
        $cacheKey = 'stripe_session_' . $sessionId;
        $cached = $this->cache->load($cacheKey);
        if (!$cached) {
            return null;
        }
        $data = json_decode($cached, true);
        return $data['quote_fingerprint'] ?? null;
    }

    public function getStoredQuoteFingerprintData(string $sessionId): ?array
    {
        $cacheKey = 'stripe_session_' . $sessionId;
        $cached = $this->cache->load($cacheKey);
        if (!$cached) {
            return null;
        }
        $data = json_decode($cached, true);
        return $data['quote_fingerprint_data'] ?? null;
    }

    public function getPaymentIntentUpdateParams($params, $paymentIntent, $filterParams = [])
    {
        $updateParams = [];
        $allowedParams = ["amount", "currency", "description", "metadata"];

        foreach ($allowedParams as $key)
        {
            if (!empty($filterParams) && !in_array($key, $filterParams))
                continue;

            if (isset($params[$key]))
                $updateParams[$key] = $params[$key];
        }

        if (!empty($updateParams["amount"]) && $updateParams["amount"] == $paymentIntent->amount)
            unset($updateParams["amount"]);

        if (!empty($updateParams["currency"]) && $updateParams["currency"] == $paymentIntent->currency)
            unset($updateParams["currency"]);

        return $updateParams;
    }

    public function getLastTransactionId(\Magento\Payment\Model\InfoInterface $payment)
    {
        if ($payment->getLastTransId())
            return $this->tokenHelper->cleanToken($payment->getLastTransId());

        if ($payment->getAdditionalInformation("checkout_session_id"))
        {
            $csId = $payment->getAdditionalInformation("checkout_session_id");
            $cs = $this->config->getStripeClient()->checkout->sessions->retrieve($csId, ['expand' => ['payment_intent', 'subscription']]);
            if (!empty($cs->payment_intent->id))
                return $cs->payment_intent->id;
        }

        return null;
    }

    /**
     * The intent which carries the payment of a Checkout Session, and which can require a
     * microdeposit verification: the session's own intent, or, for a subscription checkout, the
     * payment intent of the subscription's first invoice. A subscription-mode session has no
     * intent of its own.
     *
     * @param \Stripe\Checkout\Session $session
     * @return \Stripe\PaymentIntent|\Stripe\SetupIntent|null
     */
    public function getIntent($session)
    {
        return $this->getIntentByIds(
            $session->payment_intent ?? null,
            $session->setup_intent ?? null,
            $session->subscription ?? null
        );
    }

    /**
     * Same as getIntent(), for callers which have the intent and subscription fields of a
     * Checkout Session instead of the session object, such as the payload of the
     * checkout.session.completed event. Each field may be an id, an expanded object, or an
     * expanded array.
     *
     * @param string|array|object|null $paymentIntent
     * @param string|array|object|null $setupIntent
     * @param string|array|object|null $subscription
     * @return \Stripe\PaymentIntent|\Stripe\SetupIntent|null
     */
    public function getIntentByIds($paymentIntent, $setupIntent, $subscription)
    {
        $paymentIntentId = $this->getStripeObjectId($paymentIntent);

        if (!empty($paymentIntentId))
        {
            return $this->stripePaymentIntentFactory->create()
                ->fromPaymentIntentId($paymentIntentId)
                ->getStripeObject();
        }

        $setupIntentId = $this->getStripeObjectId($setupIntent);

        if (!empty($setupIntentId))
        {
            return $this->stripeSetupIntentFactory->create()
                ->fromSetupIntentId($setupIntentId)
                ->getStripeObject();
        }

        $subscriptionId = $this->getStripeObjectId($subscription);

        if (empty($subscriptionId))
        {
            return null;
        }

        return $this->getSubscriptionPaymentIntent($subscriptionId);
    }

    /**
     * The payment intent of a subscription's latest invoice. The invoice's own `payment_intent`
     * field is not returned by the pinned API version, so the intent is resolved through the
     * invoice's payments.
     *
     * @param string $subscriptionId
     * @return \Stripe\PaymentIntent|null
     */
    public function getSubscriptionPaymentIntent($subscriptionId)
    {
        $subscription = $this->stripeSubscriptionFactory->create()
            ->fromSubscriptionId($subscriptionId)
            ->getStripeObject();

        $paymentIntentId = $this->invoicePaymentsHelper->getLatestPaymentIntentIdFromSubscription($subscription);

        if (empty($paymentIntentId))
        {
            return null;
        }

        return $this->stripePaymentIntentFactory->create()
            ->fromPaymentIntentId($paymentIntentId)
            ->getStripeObject();
    }

    /**
     * The id of a Stripe object which may have been given as an id, an expanded object, or an
     * expanded array.
     *
     * @param string|array|object|null $object
     * @return string|null
     */
    private function getStripeObjectId($object)
    {
        if (is_string($object) || is_numeric($object))
        {
            return (string)$object;
        }

        if (is_array($object))
        {
            return $object['id'] ?? null;
        }

        if (is_object($object))
        {
            return $object->id ?? null;
        }

        return null;
    }
}
