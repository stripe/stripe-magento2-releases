<?php

declare(strict_types=1);

namespace StripeIntegration\Payments\Helper;

/**
 * Mandate data are largely deprecated as the front-end uses Confirmation Tokens or Elements with Checkout Sessions.
 * The class is kept for backwards compatibility with custom storefronts that have not yet migrated to the new flows.
 * It is also used by the integration tests, as we cannot confirm SetupIntents or PaymentIntents at the front-end in the test suite.
 */
class MandateData
{
    /**
     * Payment methods which do not support mandate_data / customer_acceptance.
     */
    private const UNSUPPORTED_METHODS = [
        'afterpay_clearpay',
        'blik',
        'kr_card',
        'kakao_pay',
        'samsung_pay',
        'naver_pay',
        'payco'
    ];

    private $remoteAddress;
    private $httpHeader;

    public function __construct(
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        \Magento\Framework\HTTP\Header $httpHeader
    ) {
        $this->remoteAddress = $remoteAddress;
        $this->httpHeader = $httpHeader;
    }

    /**
     * Builds the customer_acceptance mandate data for a payment method from the customer's
     * remote IP address and user agent.
     *
     * Returns an empty array when the request context is missing (e.g. CLI/cron) or when
     * the payment method does not support mandates.
     *
     * @param \Stripe\PaymentMethod $paymentMethod
     * @return array
     */
    public function getCustomerAcceptance($paymentMethod): array
    {
        $remoteAddress = $this->remoteAddress->getRemoteAddress();
        $userAgent = $this->httpHeader->getHttpUserAgent();

        if (!$remoteAddress || !$userAgent || empty($paymentMethod->type) || in_array($paymentMethod->type, self::UNSUPPORTED_METHODS))
        {
            return [];
        }

        return [
            "customer_acceptance" => [
                "type" => "online",
                "online" => [
                    "ip_address" => $remoteAddress,
                    "user_agent" => $userAgent,
                ]
            ]
        ];
    }

    /**
     * Builds the full mandate_data parameter for a PaymentIntent confirmation.
     *
     * Returns an empty array when mandate data is not applicable or not available.
     *
     * @param \Stripe\PaymentMethod $paymentMethod
     * @return array
     */
    public function getMandateData($paymentMethod): array
    {
        $customerAcceptance = $this->getCustomerAcceptance($paymentMethod);

        if (empty($customerAcceptance))
        {
            return [];
        }

        return [
            "mandate_data" => $customerAcceptance
        ];
    }

    /**
     * ACSS debit mandate options required by Stripe for ACSS debit payments.
     *
     * @return array
     */
    public function getAcssDebitMandateOptions(): array
    {
        return [
            'acss_debit' => [
                'mandate_options' => [
                    'payment_schedule' => 'sporadic',
                    'transaction_type' => 'personal',
                ]
            ]
        ];
    }

    /**
     * A PayPal payment method can hold only a single mandate. When the customer already has a
     * subscription (or saved payment method) linked to a PayPal payment method, Stripe rejects
     * confirming another SetupIntent with that payment method because a second mandate cannot be
     * attached. The existing mandate covers the new subscription's recurring charges, so the
     * module does not need to confirm a new SetupIntent in that case.
     */
    public function isPayPalMultipleMandatesError(\Stripe\Exception\InvalidRequestException $e): bool
    {
        if ($e->getError()->code !== 'setup_intent_invalid_parameter')
            return false;

        return stripos($e->getMessage(), 'multiple mandates') !== false;
    }
}
