<?php

namespace StripeIntegration\Payments\Helper;

use Magento\Payment\Model\InfoInterface;

/**
 * Delayed notification payment methods do not settle at order placement time. Stripe tells us what
 * the customer still has to do through the intent's `next_action`:
 *
 *  - ACH Direct Debit returns `verify_with_microdeposits` with a hosted verification URL.
 *  - Voucher methods (Boleto, OXXO, Konbini, Multibanco) return a `<type>_display_details` next
 *    action carrying a hosted voucher URL.
 *
 * This helper detects that next action, records it on the order payment, and exposes it so that the
 * order email and the checkout success page can link the customer to it.
 */
class PendingPaymentAction
{
    public const TYPE_MICRODEPOSITS = 'microdeposits';
    public const TYPE_VOUCHER = 'voucher';

    // Payment additional_information keys
    public const TYPE_KEY = 'pending_payment_action_type';
    public const URL_KEY = 'pending_payment_action_url';

    // Written by older module versions for ACH; still read so that orders placed before this
    // change keep displaying their verification link.
    public const LEGACY_MICRODEPOSIT_URL_KEY = 'microdeposit_verification_url';

    /**
     * Detect a pending action from the `next_action` of a Stripe intent. Works on PaymentIntents,
     * SetupIntents and the payment intents of subscriptions.
     *
     * @param \Stripe\PaymentIntent|\Stripe\SetupIntent|\Stripe\Subscription|null $intent
     * @return array|null ['type' => string, 'url' => string]
     */
    public function getFromIntent($intent)
    {
        $type = $intent->next_action->type ?? null;

        if (empty($type) || !is_string($type))
        {
            return null;
        }

        if ($type == 'verify_with_microdeposits')
        {
            return $this->buildAction(
                self::TYPE_MICRODEPOSITS,
                $intent->next_action->verify_with_microdeposits->hosted_verification_url ?? null
            );
        }

        // Voucher methods nest their details under the next action type, e.g.
        // next_action.boleto_display_details.hosted_voucher_url
        return $this->buildAction(
            self::TYPE_VOUCHER,
            $intent->next_action->$type->hosted_voucher_url ?? null
        );
    }

    /**
     * Record the pending action on the order payment. Returns null when there is nothing pending,
     * so callers can cheaply branch on the result.
     *
     * @param InfoInterface $payment
     * @param \Stripe\PaymentIntent|\Stripe\SetupIntent|\Stripe\Subscription|null $intent
     * @return array|null ['type' => string, 'url' => string]
     */
    public function recordOnPayment(InfoInterface $payment, $intent)
    {
        $action = $this->getFromIntent($intent);

        if (empty($action))
        {
            return null;
        }

        $payment->setAdditionalInformation(self::TYPE_KEY, $action['type']);
        $payment->setAdditionalInformation(self::URL_KEY, $action['url']);

        return $action;
    }

    /**
     * The pending action recorded on a payment, if any. Falls back to the microdeposit key written
     * by older module versions.
     *
     * @param InfoInterface $payment
     * @return array|null ['type' => string, 'url' => string]
     */
    public function getFromPayment($payment)
    {
        $url = $payment->getAdditionalInformation(self::URL_KEY);

        if (!empty($url) && is_string($url))
        {
            $type = $payment->getAdditionalInformation(self::TYPE_KEY);

            return [
                'type' => !empty($type) ? $type : self::TYPE_VOUCHER,
                'url' => $url,
            ];
        }

        $legacyUrl = $payment->getAdditionalInformation(self::LEGACY_MICRODEPOSIT_URL_KEY);

        if (!empty($legacyUrl) && is_string($legacyUrl))
        {
            return [
                'type' => self::TYPE_MICRODEPOSITS,
                'url' => $legacyUrl,
            ];
        }

        return null;
    }

    /**
     * @param InfoInterface $payment
     * @return string|null
     */
    public function getUrl($payment)
    {
        $action = $this->getFromPayment($payment);

        return $action['url'] ?? null;
    }

    /**
     * @param InfoInterface $payment
     * @return string|null
     */
    public function getType($payment)
    {
        $action = $this->getFromPayment($payment);

        return $action['type'] ?? null;
    }

    /**
     * @param InfoInterface $payment
     * @return bool
     */
    public function hasPendingAction($payment)
    {
        return $this->getFromPayment($payment) !== null;
    }

    /**
     * @param string $type
     * @param mixed $url
     * @return array|null
     */
    private function buildAction($type, $url)
    {
        if (empty($url) || !is_string($url))
        {
            return null;
        }

        return [
            'type' => $type,
            'url' => $url,
        ];
    }
}
