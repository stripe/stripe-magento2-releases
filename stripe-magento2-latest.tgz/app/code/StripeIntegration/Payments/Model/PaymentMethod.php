<?php

namespace StripeIntegration\Payments\Model;

use Magento\Payment\Model\InfoInterface;
use StripeIntegration\Payments\Exception\GenericException;
use StripeIntegration\Payments\Exception\InstallmentsException;
use StripeIntegration\Payments\Exception\RefundOfflineException;
use StripeIntegration\Payments\Helper\Installments;

class PaymentMethod extends \Magento\Payment\Model\Method\Adapter
{
    private $config;
    private $paymentElementFactory;
    private $paymentElement;
    private $paymentIntent;
    private $multishippingHelper;
    private $refundsHelper;
    private $subscriptionsHelper;
    private $helper;
    private $stripePaymentMethod;
    private $api;
    private $paymentIntentHelper;
    private $tokenHelper;
    private $setupIntentHelper;
    private $quoteHelper;
    private $orderHelper;
    private $checkoutFlow;
    private $stripePaymentIntentFactory;
    private $pendingPaymentActionHelper;
    private $checkoutSessionHelper;
    private $paymentElementResource;
    private $paymentElementCollection;
    private $cartInfo;
    private $request;
    private $installmentsHelper;
    private $subscriptionPayment;
    private $checkoutSessionFactory;
    private $checkoutSessionResource;
    private $magentoCheckoutSession;
    private $stripeCheckoutSessionFactory;
    private $cache;
    private $paymentState;

    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Payment\Gateway\Config\ValueHandlerPoolInterface $valueHandlerPool,
        \Magento\Payment\Gateway\Data\PaymentDataObjectFactory $paymentDataObjectFactory,
        string $code,
        string $formBlockType,
        string $infoBlockType,
        \StripeIntegration\Payments\Model\Config $config,
        \StripeIntegration\Payments\Model\PaymentElementFactory $paymentElementFactory,
        \StripeIntegration\Payments\Model\PaymentIntent $paymentIntent,
        \StripeIntegration\Payments\Model\Stripe\PaymentMethod $stripePaymentMethod,
        \StripeIntegration\Payments\Model\Checkout\Flow $checkoutFlow,
        \StripeIntegration\Payments\Model\Stripe\PaymentIntentFactory $stripePaymentIntentFactory,
        \StripeIntegration\Payments\Model\ResourceModel\PaymentElement $paymentElementResource,
        \StripeIntegration\Payments\Model\ResourceModel\PaymentElement\Collection $paymentElementCollection,
        \StripeIntegration\Payments\Model\Cart\Info $cartInfo,
        \StripeIntegration\Payments\Model\Subscription\Payment $subscriptionPayment,
        \StripeIntegration\Payments\Helper\Generic $helper,
        \StripeIntegration\Payments\Helper\Subscriptions $subscriptionsHelper,
        \StripeIntegration\Payments\Helper\Multishipping $multishippingHelper,
        \StripeIntegration\Payments\Helper\Refunds $refundsHelper,
        \StripeIntegration\Payments\Helper\Api $api,
        \StripeIntegration\Payments\Helper\PaymentIntent $paymentIntentHelper,
        \StripeIntegration\Payments\Helper\Token $tokenHelper,
        \StripeIntegration\Payments\Helper\SetupIntent $setupIntentHelper,
        \StripeIntegration\Payments\Helper\Quote $quoteHelper,
        \StripeIntegration\Payments\Helper\Order $orderHelper,
        \StripeIntegration\Payments\Helper\PendingPaymentAction $pendingPaymentActionHelper,
        \StripeIntegration\Payments\Helper\CheckoutSession $checkoutSessionHelper,
        \StripeIntegration\Payments\Model\CheckoutSessionFactory $checkoutSessionFactory,
        \StripeIntegration\Payments\Model\ResourceModel\CheckoutSession $checkoutSessionResource,
        \Magento\Checkout\Model\Session $magentoCheckoutSession,
        \StripeIntegration\Payments\Model\Stripe\Checkout\SessionFactory $stripeCheckoutSessionFactory,
        \StripeIntegration\Payments\Model\Order\PaymentState $paymentState,
        Installments $installmentsHelper,
        ?\Magento\Payment\Gateway\Command\CommandPoolInterface $commandPool = null,
        ?\Magento\Payment\Gateway\Validator\ValidatorPoolInterface $validatorPool = null
    ) {
        $this->request = $context->getRequest();
        $this->config = $config;
        $this->paymentElementFactory = $paymentElementFactory;
        $this->paymentIntent = $paymentIntent;
        $this->stripePaymentMethod = $stripePaymentMethod;
        $this->helper = $helper;
        $this->subscriptionsHelper = $subscriptionsHelper;
        $this->multishippingHelper = $multishippingHelper;
        $this->refundsHelper = $refundsHelper;
        $this->api = $api;
        $this->paymentIntentHelper = $paymentIntentHelper;
        $this->tokenHelper = $tokenHelper;
        $this->setupIntentHelper = $setupIntentHelper;
        $this->quoteHelper = $quoteHelper;
        $this->orderHelper = $orderHelper;
        $this->checkoutFlow = $checkoutFlow;
        $this->stripePaymentIntentFactory = $stripePaymentIntentFactory;
        $this->pendingPaymentActionHelper = $pendingPaymentActionHelper;
        $this->checkoutSessionHelper = $checkoutSessionHelper;
        $this->paymentElementResource = $paymentElementResource;
        $this->paymentElementCollection = $paymentElementCollection;
        $this->cartInfo = $cartInfo;
        $this->installmentsHelper = $installmentsHelper;
        $this->subscriptionPayment = $subscriptionPayment;
        $this->checkoutSessionFactory = $checkoutSessionFactory;
        $this->checkoutSessionResource = $checkoutSessionResource;
        $this->magentoCheckoutSession = $magentoCheckoutSession;
        $this->stripeCheckoutSessionFactory = $stripeCheckoutSessionFactory;
        $this->paymentState = $paymentState;

        if ($this->helper->isMultiShipping())
            $formBlockType = 'StripeIntegration\Payments\Block\Multishipping\Billing';
        else if ($this->helper->isAdmin())
            $formBlockType = 'StripeIntegration\Payments\Block\Adminhtml\Payment\Form';
        else
            $formBlockType = 'Magento\Payment\Block\Form';

        parent::__construct(
            $eventManager,
            $valueHandlerPool,
            $paymentDataObjectFactory,
            $code,
            $formBlockType,
            $infoBlockType,
            $commandPool,
            $validatorPool
        );
    }

    public function assignData(\Magento\Framework\DataObject $data)
    {
        parent::assignData($data);

        if ($this->config->getIsStripeAPIKeyError())
            $this->helper->throwError("Invalid API key provided");

        $additionalData = $data->getAdditionalData();

        $info = $this->getInfoInstance();

        $this->helper->assignPaymentData($info, $additionalData);

        return $this;
    }

    public function order(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        if ($this->tokenHelper->isExternalPaymentMethodToken($payment->getAdditionalInformation("token")))
        {
            $this->paymentIntent->processPendingOrderWithoutIntent($payment->getOrder());
            return $this;
        }

        $order = $payment->getOrder();

        // PEwCS (Elements with Checkout Sessions) flow: the payment method is confirmed
        // client-side inside the Checkout Session, so no SetupIntent is created server-side.
        if ($this->isPEwCSFlow($payment))
        {
            return $this->orderFromCheckoutSession($payment, $order);
        }

        $customer = $this->helper->getCustomerModel();
        $customer->createStripeCustomerIfNotExists(false, $payment->getOrder());

        $createParams = $this->setupIntentHelper->getCreateParams($payment->getOrder());
        $confirmParams = $this->setupIntentHelper->getConfirmParams($payment->getOrder());

        $paymentElement = $this->paymentElementCollection->getByQuoteId($payment->getOrder()->getQuoteId());
        if ($paymentElement->getSetupIntentId())
        {
            // Hits with 3DS2 authentication + order resubmission
            $setupIntent = $this->config->getStripeClient()->setupIntents->retrieve($paymentElement->getSetupIntentId());
        }
        else
        {
            $setupIntent = $this->config->getStripeClient()->setupIntents->create($createParams);
        }
        $paymentElement->setQuoteId($payment->getOrder()->getQuoteId());
        $paymentElement->setSetupIntentId($setupIntent->id);
        $paymentElement->setPaymentMethodId($setupIntent->payment_method);
        $paymentElement->setOrderIncrementId($payment->getOrder()->getIncrementId());
        $this->paymentElementResource->save($paymentElement);

        $payment->setAdditionalInformation("customer_stripe_id", $customer->getStripeId());
        $payment->setAdditionalInformation("payment_action", $this->config->getPaymentAction());

        // If the order was placed with a confirmation token, switch things around to a normal PM token
        $payment->setAdditionalInformation("token", $setupIntent->payment_method);
        $payment->setAdditionalInformation("confirmation_token", false);

        if ($setupIntent->status == "requires_confirmation" || $setupIntent->status == "requires_payment_method")
        {
            $setupIntent = $this->config->getStripeClient()->setupIntents->confirm($setupIntent->id, $confirmParams);
        }

        if ($setupIntent->status == "requires_action")
        {
            if ($setupIntent->next_action->type == "redirect_to_url")
            {
                // Hits with PayPal and other saveable redirect-based payment methods
                $payment->setIsCustomerRedirected(true);
                return $this;
            }
            else
            {
                return $this->helper->throwError("Authentication Required: " . $setupIntent->client_secret);
            }
        }
        else if ($setupIntent->status == "canceled")
        {
            return $this->helper->throwError("The payment method could not be saved. Please try again.");
        }
        else if (in_array($setupIntent->status, ["succeeded", "processing"]))
        {
            return $this;
        }
        else
        {
            throw new GenericException(__("Something went wrong. Please try again."));
        }

        return $this;
    }

    /**
     * PEwCS (Elements with Checkout Sessions) flow for the "order" payment action.
     *
     * In this flow the Checkout Session is created in setup mode (payment_action=order)
     * and the payment method is confirmed client-side. No SetupIntent is created
     * server-side. Load the confirmed SetupIntent from the session and store its payment
     * method as the token — mirroring what the legacy order() method does (create +
     * confirm a SetupIntent) so that downstream code (admin capture via createNewCharge,
     * saved payment methods, webhooks) works identically.
     *
     * @param InfoInterface $payment
     * @param \Magento\Sales\Model\Order $order
     * @return $this
     * @throws GenericException
     */
    private function orderFromCheckoutSession(InfoInterface $payment, $order)
    {
        // Load + validate the Checkout Session and extract the confirmed SetupIntent.
        $setupIntent = $this->loadResultFromCheckoutSession($payment, $order);

        if (empty($setupIntent) || empty($setupIntent->id))
        {
            // Order-first flow: the session is still open and the payment method has not been
            // confirmed yet. Mark the order as pending; the confirmation + webhook finalize it.
            $this->paymentIntent->processPendingOrderWithoutIntent($order);
            return $this;
        }

        // The setup intent is confirmed — store its payment method as the token.
        if (!empty($setupIntent->payment_method) && is_string($setupIntent->payment_method))
        {
            $payment->setAdditionalInformation("token", $setupIntent->payment_method);
        }
        $payment->setAdditionalInformation("confirmation_token", false);

        if (!empty($setupIntent->customer))
        {
            $payment->setAdditionalInformation("customer_stripe_id", $setupIntent->customer);
        }

        $payment->setAdditionalInformation("payment_action", $this->config->getPaymentAction());

        return $this;
    }

    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        if ($this->tokenHelper->isExternalPaymentMethodToken($payment->getAdditionalInformation("token")))
        {
            $this->paymentIntent->processPendingOrderWithoutIntent($payment->getOrder());
            return $this;
        }
        else if ($this->checkoutFlow->isSubscriptionUpdate)
        {
            $this->subscriptionsHelper->updateSubscription($payment);
        }
        else if ($this->helper->isMultiShipping())
        {
            $this->doNotPay($payment);
        }
        else if ($payment->getAdditionalInformation('is_migrated_subscription'))
        {
            $this->doNotPay($payment);
        }
        else if ($this->checkoutFlow->creatingOrderFromCharge)
        {
            $this->createOrderFromCharge($payment);
        }
        else
        {
            $this->pay($payment, $amount);
        }

        return $this;
    }

    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        if ($this->tokenHelper->isExternalPaymentMethodToken($payment->getAdditionalInformation("token")))
        {
            $this->paymentIntent->processPendingOrderWithoutIntent($payment->getOrder());
            return $this;
        }

        $token = $payment->getTransactionId();
        if (empty($token))
        {
            $token = $payment->getLastTransId(); // In case where the transaction was not created during the checkout, i.e. with a Stripe Webhook redirect
        }

        if ($payment->getAdditionalInformation('payment_action') == "order")
        {
            $this->api->createNewCharge($payment, $amount);
        }
        else if ($token)
        {
            // Capture an authorized payment from the admin area
            $token = $this->tokenHelper->cleanToken($token);

            $orders = $this->helper->getOrdersByTransactionId($token);
            $quoteId = (($payment->getOrder() && $payment->getOrder()->getQuoteId()) ? $payment->getOrder()->getQuoteId() : null);
            if ($this->multishippingHelper->isMultishippingQuote($quoteId))
            {
                if (count($orders) > 1)
                {
                    $this->multishippingHelper->captureOrdersFromAdminArea($orders, $token, $payment, $amount, $this->config->retryWithSavedCard());
                }
                else
                {
                    return $this->helper->throwError(__("This order cannot be captured because no transactions have been recorded against it."));
                }
            }
            else
            {
                $customCaptureAmount = $this->getCustomCaptureAmount($payment, $amount);
                if ($customCaptureAmount)
                {
                    $this->helper->capture($token, $payment, $customCaptureAmount, false);
                }
                else
                {
                    $this->helper->capture($token, $payment, $amount, $this->config->retryWithSavedCard());
                }
            }
        }
        else if ($payment->getAdditionalInformation('is_migrated_subscription'))
        {
            return $this->helper->throwError(__("It is not possible to capture subscription orders that were created from the CLI."));
        }
        else if ($this->helper->isAdmin() && $payment->getOrder()->getState() == "pending_payment")
        {
            return $this->helper->throwError(__("It is not possible to capture the payment because the transaction has not yet been authorized."));
        }
        else if ($this->helper->isMultiShipping())
        {
            $this->doNotPay($payment);
        }
        else if ($this->checkoutFlow->creatingOrderFromCharge)
        {
            $this->createOrderFromCharge($payment);
        }
        else if ($this->checkoutFlow->isRecurringSubscriptionOrderBeingPlaced)
        {
            $paymentIntent = $this->subscriptionPayment->getPaymentIntent();
            if (!$paymentIntent)
            {
                $this->doNotPay($payment);
            }
            else
            {
                $this->paymentIntent->processRecurringSubscriptionOrder($payment->getOrder(), $paymentIntent);
            }
            return $this;
        }
        else
        {
            $this->pay($payment, $amount);
        }

        return $this;
    }

    public function doNotPay(\Magento\Payment\Model\InfoInterface $payment)
    {
        $payment->setIsFraudDetected(false);
        $payment->setIsTransactionPending(true); // not authorized yet
        $payment->setIsTransactionClosed(false); // not captured
        $payment->getOrder()->setCanSendNewEmailFlag(false);
    }

    private function isPEwCSFlow(InfoInterface $payment)
    {
        return $this->config->usePaymentElementWithCheckoutSessions()
            && $payment->getAdditionalInformation("checkout_session_id");
    }

    public function pay(InfoInterface $payment, $amount)
    {
        $order = $payment->getOrder();

        try
        {
            if ($this->isPEwCSFlow($payment))
            {
                $result = $this->loadResultFromCheckoutSession($payment, $order);

                // The order is placed first in the Elements with Checkout Sessions flow. If the
                // customer backs out of a redirect-based payment method's authorization page
                // without completing the payment, the checkout page controller would redirect
                // them to an empty cart (the quote is inactive after order placement). Set a
                // marker in the checkout session so that the checkout page cancels the pending
                // order and restores the quote before that redirect happens.
                $this->magentoCheckoutSession->setStripePaymentsWcsRestoreOrder($order->getIncrementId());
            }
            else
            {
                $result = $this->loadResultFromPaymentElement($payment, $order, $amount);
            }

            if (empty($result)) {
                // PEwCS case: The order is placed first, then redirecting to an external payment method.
                $this->paymentIntent->processPendingOrderWithoutIntent($order);
                return $this;
            }

            if (!empty($result->client_secret)) // Trial subscriptions will not have a client secret
            {
                $payment->setAdditionalInformation("client_secret", $result->client_secret);
            }
        }
        catch (InstallmentsException $e) {
            throw $e;
        }
        catch (\Exception $e)
        {
            $this->helper->sendPaymentFailedEmail($this->quoteHelper->getQuote(), $e->getMessage());
            throw $e;
        }

        $this->pendingPaymentActionHelper->recordOnPayment($payment, $result);

        if ($this->checkoutFlow->isPendingMicrodepositsVerification)
        {
            if ($this->tokenHelper->isSetupIntentToken($result->id))
            {
                $this->paymentIntent->processPendingOrder($order, $result);
            }
            else
            {
                throw new GenericException(__("Something went wrong. Please contact us for assistance."));
            }
        }
        else if ($this->paymentIntent->requiresAction($result))
        {
            if ($this->helper->isAdmin() && $this->paymentIntentHelper->requiresOnlineAction($result))
            {
                return $this->helper->throwError(__("This payment method cannot be used because it requires a customer authentication. To avoid authentication in the admin area, please contact Stripe support to request access to the MOTO gate for your Stripe account."));
            }

            if ($this->shouldAuthenticateManually($result))
            {
                return $this->helper->throwError("Authentication Required: {$result->client_secret}");
            }

            $this->paymentIntent->processPendingOrder($order, $result);
        }
        else if ($this->paymentElement->isTrialSubscription())
        {
            $this->paymentIntent->processTrialSubscriptionOrder($order, $this->paymentElement->getSubscription());
        }
        else if ($this->paymentElement->getPaymentIntent())
        {
            if ($this->paymentIntentHelper->isSuccessful($result))
            {
                $this->paymentIntent->processSuccessfulOrder($order, $result);
            }
            else
            {
                $this->paymentIntent->processPendingOrder($order, $result);
            }
            $payment->setAdditionalInformation("server_side_transaction_id", $result->id);
        }
        else if ($this->checkoutFlow->isFutureSubscriptionSetup)
        {
            // The subscription starts at a future date
            if ($this->tokenHelper->isSubscriptionToken($result->id))
            {
                $this->paymentIntent->processFutureSubscriptionOrder($order, $result);
            }
            else if ($this->tokenHelper->isSetupIntentToken($result->id))
            {
                $this->paymentIntent->processFutureSubscriptionOrder($order, $this->paymentElement->getSubscription());
            }
            else
            {
                throw new GenericException(__("Something went wrong. Please contact us for assistance."));
            }
        }
        else if ($this->paymentElement->getSetupIntent())
        {
            if ($order->getGrandTotal() == 0)
            {
                if ($this->cartInfo->hasTrialSubscriptions())
                {
                    $this->paymentIntent->processTrialSubscriptionOrder($order, $this->paymentElement->getSubscription());
                }
                else
                {
                    // In theory we should never get here
                    $this->paymentIntent->processSuccessfulOrder($order, $result);
                }
            }
            else
            {
                // In theory we should never get here because a payment intent will be available
                $this->paymentIntent->processPendingOrder($order, $result);
            }
        }
    }

    /**
     * Legacy flow: load the PaymentElement from the quote, update it from the order,
     * cancel any stale orders, validate installments, and confirm the payment server-side.
     *
     * @param InfoInterface $payment
     * @param $order
     * @param $amount
     * @return \Stripe\PaymentIntent|\Stripe\SetupIntent|\Stripe\Subscription The confirmed result
     * @throws \Exception
     */
    private function loadResultFromPaymentElement(InfoInterface $payment, $order, $amount)
    {
        if (!$payment->getAdditionalInformation("token") && !$payment->getAdditionalInformation("confirmation_token"))
            return $this->helper->throwError(__("Cannot place order because a payment method was not provided."));

        // Update the payment intent by loading it from cache - the load method will update it if it's different.
        $this->paymentElement = $this->paymentElementFactory->create()->fromQuoteId($order->getQuoteId());
        $this->paymentElement->updateFromOrder($order);
        $this->paymentElement->cancelInvalidOrders($order);

        $this->checkInstallments($payment, $order);

        return $this->paymentElement->confirm($order);
    }

    /**
     * PEwCS (Elements with Checkout Sessions) flow: the payment has already been confirmed
     * client-side. Retrieve the Checkout Session from Stripe, validate it, extract the
     * PI/SI/subscription, and populate $this->paymentElement so the existing branching
     * in pay() processes the result identically to the legacy flow.
     *
     * @param InfoInterface $payment
     * @param $order
     * @return \Stripe\PaymentIntent|\Stripe\SetupIntent|\Stripe\Subscription|\stdClass|null The confirmed result, or a dummy with id=null if already handled
     * @throws GenericException
     */
    private function loadResultFromCheckoutSession(InfoInterface $payment, $order)
    {
        $checkoutSessionId = $this->magentoCheckoutSession->getStripePaymentsCheckoutSessionId();

        if (empty($checkoutSessionId))
        {
            $checkoutSessionId = $payment->getAdditionalInformation("checkout_session_id");
        }

        if (empty($checkoutSessionId))
        {
            throw new GenericException(__("Cannot place order because a checkout session was not found."));
        }

        $quoteId = $order->getQuoteId();

        $quote = $this->quoteHelper->loadQuoteById($quoteId);
        if (!$quote || !$quote->getId())
        {
            throw new GenericException((string)__("Order quote could not be loaded."));
        }

        // Load local session row. It may be missing (e.g. the order was placed through a flow that did
        // not persist it) or stale (the quote was replaced during checkout). In both cases, create or
        // update the record instead of failing, so it always points at the current order.
        $checkoutSessionModel = $this->checkoutSessionFactory->create();
        $this->checkoutSessionResource->load($checkoutSessionModel, $checkoutSessionId, 'checkout_session_id');

        if (!$checkoutSessionModel->getId() || (int)$checkoutSessionModel->getQuoteId() !== (int)$quoteId)
        {
            $checkoutSessionModel->setQuoteId($quoteId);
            $checkoutSessionModel->setOrderIncrementId($order->getIncrementId());
            $checkoutSessionModel->setCheckoutSessionId($checkoutSessionId);
            $this->checkoutSessionResource->save($checkoutSessionModel);
        }

        // Load and validate Stripe Session with expanded objects
        /** @var \StripeIntegration\Payments\Model\Stripe\Checkout\Session $stripeSessionModel */
        $stripeSessionModel = $this->stripeCheckoutSessionFactory->create()->fromSessionId($checkoutSessionId);
        /** @var \Stripe\Checkout\Session $session */
        $session = $stripeSessionModel->getStripeObject();

        if ($session->mode !== 'setup')
        {
            // The checkout session total and currency must match the order.
            $sessionAmount = $session->amount_total ?? null;
            $sessionCurrency = $session->currency ?? null;
            $orderAmount = $this->helper->convertMagentoAmountToStripeAmount($order->getGrandTotal(), $order->getOrderCurrencyCode());
            $orderCurrency = $order->getOrderCurrencyCode();

            if ($sessionAmount === null || $sessionCurrency === null ||
                strtolower($sessionCurrency) !== strtolower($orderCurrency) ||
                (int)$sessionAmount !== (int)$orderAmount)
            {
                $this->helper->logError(
                    "Checkout session amount/currency mismatch for checkout session " . $session->id .
                    ". Session: " . $sessionAmount . " " . ($sessionCurrency ?: '') .
                    ". Order: " . $orderAmount . " " . $orderCurrency . "."
                );
                throw new GenericException((string)__("The order total has changed. Please refresh the page and try again."));
            }
        }

        // Create a PaymentElement and populate its in-memory fields from the session
        // so the existing branching in pay() works unchanged.
        $this->paymentElement = $this->paymentElementFactory->create();

        // Handle expired
        if ($session->status === 'expired')
        {
            $this->magentoCheckoutSession->restoreQuote();
            throw new GenericException((string)__("The payment session has expired. Please try placing the order again."));
        }

        if ($session->status === 'open')
        {
            // Order-first flow: the Magento order is placed before payment confirmation.
            // If a PI exists, return it so the branching calls processPendingOrder() which
            // sets the transaction ID — matching the legacy flow's requires_confirmation case.
            // If no PI is available, mark pending without intent and signal "already handled".
            $pi = $session->payment_intent ?? null;
            if ($pi)
            {
                $this->paymentElement->setPaymentIntent($pi);
                $payment->setAdditionalInformation('server_side_transaction_id', $pi->id);
                return $pi;
            }

            // No PI on an open session — mark pending without intent
            $payment->setAdditionalInformation('server_side_transaction_id', null);
            return null;
        }

        if ($session->status !== 'complete')
        {
            throw new GenericException((string)__("Unknown checkout session status: %1.", $session->status));
        }

        // Session is 'complete' — extract the confirmed result

        if (!empty($session->payment_intent))
        {
            /** @var \Stripe\PaymentIntent $pi */
            $pi = $session->payment_intent;
            $this->paymentElement->setPaymentIntent($pi);
            $payment->setAdditionalInformation('server_side_transaction_id', $pi->id);
            $this->paymentState->setConfirmedPaymentIntent($pi);

            return $pi;
        }

        if (!empty($session->subscription))
        {
            /** @var string|\Stripe\Subscription $subscription */
            $subscription = $session->subscription;
            $this->paymentElement->setSubscription($subscription);
            $this->paymentElement->setSubscriptionId($subscription->id); // Used in the isFutureSubscriptionSetup branch

            // Get invoice PI if available (never dereference latest_invoice if string)
            /** @var \Stripe\PaymentIntent|null $invoicePi */
            $invoicePi = null;
            if (!empty($subscription->latest_invoice) && !is_string($subscription->latest_invoice))
            {
                $invoicePi = $subscription->latest_invoice->payment_intent ?? null;
            }

            if ($invoicePi)
            {
                // Classify/record like top-level PI
                $this->paymentElement->setPaymentIntent($invoicePi);
                $payment->setAdditionalInformation('server_side_transaction_id', $invoicePi->id);
                $this->paymentState->setConfirmedPaymentIntent($invoicePi);

                return $invoicePi;
            }

            if (!empty($session->setup_intent))
            {
                /** @var \Stripe\SetupIntent $si */
                $si = $session->setup_intent;
                $this->paymentElement->setSetupIntent($si);
                $this->paymentState->setSubscriptionWithoutPayment($session->subscription);

                if ($subscription->status === 'trialing'
                    || (!empty($subscription->trial_end) && $subscription->trial_end > time()))
                {
                    // Trial subscription — return the subscription so isTrialSubscription() matches.
                    // Do not set setup_intent_id in the data bag, otherwise isTrialSubscription() would return false.
                    $payment->setAdditionalInformation('server_side_transaction_id', null);
                    return $subscription;
                }

                // Future subscription setup — return the SI
                $payment->setAdditionalInformation('server_side_transaction_id', null);
                return $si;
            }

            // No invoice PI and no setup_intent — mark pending for webhook
            $payment->setAdditionalInformation('server_side_transaction_id', null);
            return null;
        }

        if (!empty($session->setup_intent))
        {
            // Setup-mode sessions (payment_action=order) contain a SetupIntent rather than
            // a PaymentIntent. Return it so orderFromCheckoutSession() can store the confirmed
            // payment method as the token.
            /** @var \Stripe\SetupIntent $si */
            $si = $session->setup_intent;
            $this->paymentElement->setSetupIntent($si);
            $payment->setAdditionalInformation('server_side_transaction_id', null);
            return $si;
        }

        throw new GenericException((string)__("Checkout session is complete but has no associated payment, subscription, or setup intent."));
    }

    private function shouldAuthenticateManually($intent)
    {
        $methods = $this->config->getManualAuthenticationPaymentMethods();

        if (!empty($intent->payment_method) && is_string($intent->payment_method))
        {
            $paymentMethod = $this->stripePaymentMethod->fromPaymentMethodId($intent->payment_method)->getStripeObject();

            if (in_array($paymentMethod->type, $methods))
            {
                return true;
            }
        }
        else if (!empty($intent->payment_method->type) && in_array($intent->payment_method->type, $methods))
        {
            return true;
        }

        return false;
    }

    public function cancel(InfoInterface $payment, $amount = null)
    {
        if ($payment->getCancelOfflineWithComment())
        {
            $this->helper->overrideCancelActionComment($payment, $payment->getCancelOfflineWithComment());
            return $this;
        }

        try
        {
            $paymentIntentId = $this->refundsHelper->getTransactionId($payment);
            $paymentIntent = $this->config->getStripeClient()->paymentIntents->retrieve($paymentIntentId, []);

            if ($this->checkoutFlow->isCleaningExpiredOrders)
            {
                // Triggered via the Pending Payment Order Lifetime cron job.
                if ($this->paymentIntentHelper->isSuccessful($paymentIntent) ||
                    $this->paymentIntentHelper->requiresOfflineAction($paymentIntent) ||
                    $this->paymentIntentHelper->isAsyncProcessing($paymentIntent))
                {
                    // Case where the payment succeeded but the charge.succeeded event has not yet been processed
                    return $this->helper->throwError(__("The order could not be canceled because the payment is still being processed."));
                }
            }

            if ($this->multishippingHelper->isMultishippingPayment($paymentIntent) && $paymentIntent->status == "requires_capture")
            {
                $this->refundsHelper->refundMultishipping($paymentIntent, $payment, $amount);
            }
            else
            {
                $this->refundsHelper->refund($payment, $amount);
            }
        }
        catch (RefundOfflineException $e)
        {
            if ($this->helper->isAdmin())
            {
                $this->helper->addWarning($e->getMessage());
            }

            if ($this->refundsHelper->isCancelation($payment))
                $this->helper->overrideCancelActionComment($payment, $e->getMessage());
            else
                $this->orderHelper->addOrderComment($e->getMessage(), $payment->getOrder());
        }
        catch (\Stripe\Exception\InvalidRequestException $e)
        {
            if ($e->getStripeCode() == "resource_missing")
            {
                $this->orderHelper->addOrderComment("The payment could not be refunded because the transaction was not found in Stripe.", $payment->getOrder());
                return $this;
            }

            return $this->helper->throwError(__('Could not refund payment: %1', $e->getMessage()), $e);
        }
        catch (\Exception $e)
        {
            return $this->helper->throwError(__('Could not refund payment: %1', $e->getMessage()), $e);
        }

        return $this;
    }

    public function refund(InfoInterface $payment, $amount)
    {
        $this->cancel($payment, $amount);

        return $this;
    }

    public function void(InfoInterface $payment)
    {
        $this->cancel($payment);

        return $this;
    }

    public function acceptPayment(InfoInterface $payment)
    {
        return parent::acceptPayment($payment);
    }

    public function denyPayment(InfoInterface $payment)
    {
        return parent::denyPayment($payment);
    }

    public function canCapture()
    {
        $info = $this->getInfoInstance();
        if ($info)
        {
            $paymentAction = $info->getAdditionalInformation("payment_action");
            $token = $info->getAdditionalInformation("token");
            if ($paymentAction == "order" && !empty($token))
            {
                return true;
            }
        }
        return parent::canCapture();
    }

    public function isAvailable(?\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        if ($this->checkoutFlow->isPaymentMethodAvailable())
            return true;

        if ($this->checkoutSessionHelper->isSubscriptionUpdate())
            return true;

        if (!$this->config->isEnabled())
            return false;

        $isSubscriptionUpdate = $this->checkoutSessionHelper->isSubscriptionUpdate();

        if ($quote && $this->subscriptionsHelper->hasSubscriptions($quote))
        {
            $hasNonBillableSubscriptionItems = !empty($this->quoteHelper->getNonBillableSubscriptionItems($quote->getAllItems()));
            $hasFullyDiscountedSubscriptions = $this->quoteHelper->hasFullyDiscountedSubscriptions($quote);
            $isZeroTotalSubscriptionFromAdjustment = $this->quoteHelper->isZeroTotalSubscriptionFromAdjustment($quote);
        }
        else
        {
            $hasNonBillableSubscriptionItems = false;
            $hasFullyDiscountedSubscriptions = false;
            $isZeroTotalSubscriptionFromAdjustment = false;
        }

        if ($this->config->isRedirectPaymentFlow() && !$this->isExpressCheckout() && !$this->helper->isMultiShipping() && !$this->helper->isAdmin())
            return false;

        return $hasNonBillableSubscriptionItems ||
            $hasFullyDiscountedSubscriptions ||
            $isZeroTotalSubscriptionFromAdjustment ||
            $isSubscriptionUpdate ||
            parent::isAvailable($quote);
    }

    public function isExpressCheckout()
    {
        return $this->checkoutFlow->isExpressCheckout;
    }

    public function getConfigPaymentAction()
    {
        $info = $this->getInfoInstance();
        if ($info && $info->getAdditionalInformation("is_migrated_subscription") ||
            $this->checkoutSessionHelper->isSubscriptionUpdate())
        {
            return 'authorize';
        }

        // Subscriptions do not support authorize only mode
        if ($this->subscriptionsHelper->hasSubscriptions())
        {
            return 'authorize_capture';
        }

        return $this->config->getPaymentAction();
    }

    public function canEdit()
    {
        $info = $this->getInfoInstance();

        if (!empty($info->getTransactionId()))
            return false;

        if (!empty($info->getLastTransId()))
            return false;

        if (empty($info->getAdditionalInformation("token")))
            return false;

        if (empty($info->getAdditionalInformation("customer_stripe_id")))
            return false;

        $token = $info->getAdditionalInformation("token");

        if (strpos($token, "pm_") !== 0)
            return false;

        return true;
    }

    protected function getConfig()
    {
        return $this->config;
    }

    private function createOrderFromCharge($payment)
    {
        $charge = $this->checkoutFlow->creatingOrderFromCharge;
        if (empty($charge['payment_intent']))
        {
            return $this->helper->throwError("The charge has no payment intent.");
        }

        $stripePaymentIntentModel = $this->stripePaymentIntentFactory->create()->fromPaymentIntentId($charge['payment_intent']);
        $this->paymentIntent->processSuccessfulOrder($payment->getOrder(), $stripePaymentIntentModel->getStripeObject());
    }

    public function getCustomCaptureAmount($payment, $amount)
    {
        if (!$this->config->isOvercaptureEnabled())
        {
            return null;
        }

        $data = $this->request->getPost('invoice');

        if (empty($data['custom_capture_amount']))
        {
            return null;
        }

        if (!is_numeric($data['custom_capture_amount']))
        {
            $this->helper->throwError("Invalid custom capture amount " . $data['custom_capture_amount']);
        }

        if ($data['custom_capture_amount'] <= 0)
        {
            $this->helper->throwError("Invalid custom capture amount " . $data['custom_capture_amount']);
        }

        return $data['custom_capture_amount'];
    }

    public function checkInstallments($payment, $order)
    {
        $paymentIntent = $this->paymentElement->getPaymentIntent();
        if ($this->config->isMsiEnabled() &&
            isset($paymentIntent->payment_method_options->card->installments->available_plans) &&
            $paymentIntent->payment_method_options->card->installments->available_plans
        ) {
            if (!$payment->getAdditionalInformation("selected_installment_plan")) {
                $installmentsDetails = $this->installmentsHelper->getInstallmentsPlanDetails(
                    $paymentIntent->payment_method_options->card->installments->available_plans,
                    $order
                );
                $this->helper->getCheckoutSession()->setInstallmentPlans(
                    $installmentsDetails
                );

                throw new InstallmentsException('Select Installments');
            }
        }
    }
}
