<?php

declare(strict_types=1);

namespace StripeIntegration\Payments\Model;

use StripeIntegration\Payments\Exception\WebhookException;
use StripeIntegration\Payments\Exception\GenericException;

class WebhookEvent extends \Magento\Framework\Model\AbstractModel
{
    private array $event;
    private $stdEvent;
    private $dateTime;
    private $config;
    private $webhooksHelper;
    private $resourceModel;
    private $orderHelper;

    public function __construct(
        \StripeIntegration\Payments\Helper\Webhooks $webhooksHelper,
        \StripeIntegration\Payments\Helper\Order $orderHelper,
        \StripeIntegration\Payments\Model\Config $config,
        \Magento\Framework\Stdlib\DateTime $dateTime,
        \StripeIntegration\Payments\Model\ResourceModel\WebhookEvent $resourceModel,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ?\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        ?\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->orderHelper = $orderHelper;
        $this->webhooksHelper = $webhooksHelper;
        $this->config = $config;
        $this->dateTime = $dateTime;
        $this->resourceModel = $resourceModel;

        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    protected function _construct()
    {
        $this->_init('StripeIntegration\Payments\Model\ResourceModel\WebhookEvent');
    }

    public function fromStripeObject(array $event, bool $processMoreThanOnce)
    {
        if (empty($event['id']) || empty($event['type']))
        {
            throw new WebhookException("Invalid event data specified", 400);
        }

        $this->setEventId($event['id']);
        $this->setEventType($event['type']);

        if (!empty($event['data']['object']))
        {
            $object = $event['data']['object'];
            if (!empty($object['object']) && $object['object'] == "payment_intent")
            {
                $this->setPaymentIntentId($object['id']);
            }
            else if (!empty($object['payment_intent']) && is_string($object['payment_intent']))
            {
                $this->setPaymentIntentId($object['payment_intent']);
            }
        }

        try
        {
            // When the same event arrives multiple times, even in parallel, we expect that InnoDB
            // will fail with a unique constraint violation error. InnoDB writes are serial.
            $this->resourceModel->save($this);
        }
        catch (\Magento\Framework\Exception\AlreadyExistsException $e)
        {
            $this->resourceModel->load($this, $event['id'], 'event_id');

            if (!$processMoreThanOnce)
            {
                if ($this->getIsProcessed())
                {
                    throw new WebhookException(__("Already processed in previous request."), 202);
                }
                else
                {
                    throw new WebhookException(__("Event is queued for processing."), 202);
                }
            }
        }

        $this->event = $event;

        return $this;
    }

    public function markAsProcessed()
    {
        $this->setIsProcessed(true);
        $this->setProcessedAt($this->dateTime->formatDate(true));
        $this->setLastError(null);
        $this->setLastErrorStatusCode(null);
        $this->setLastErrorAt(null);
        $this->resourceModel->save($this);

        return $this;
    }

    public function setLastErrorFromException(\Throwable $e, $statusCode = 202)
    {
        $txt = sprintf("[%s] %s\n%s.", \StripeIntegration\Payments\Model\Config::$moduleVersion, $e->getMessage(), $e->getTraceAsString());
        $this->setLastError($txt);
        // Always record a status code: the presence of last_error_status_code is what marks an
        // event as having had a failed processing attempt (see process()).
        $this->setLastErrorStatusCode($statusCode ?: 202);
        $this->setLastErrorAt($this->dateTime->formatDate(true));
        $this->resourceModel->save($this);

        return $this;
    }

    // Use this if the DB entry may have been mutated at other places in the codebase and we need to refresh the object.
    public function refresh()
    {
        if ($this->getEventId())
        {
            $this->resourceModel->load($this, $this->getEventId(), 'event_id');
        }
        else
        {
            $this->resourceModel->load($this, $this->event['id'], 'event_id');
        }

        return $this;
    }

    public function process($stripeClient = null)
    {
        if (!$this->getEventId())
        {
            throw new GenericException("Event ID has not been set.");
        }

        if (!$this->shouldRetry())
        {
            return;
        }

        // The first processing attempt is not a retry. A previous attempt is detected by the
        // presence of a last error status code, which every failure path records. This keeps
        // retries at 0 when an event is processed successfully on its first attempt.
        if ($this->getLastErrorStatusCode() !== null)
        {
            $this->setRetries($this->getRetries() + 1)->save();
        }

        if (empty($this->stdEvent))
        {
            if ($stripeClient)
            {
                $this->stdEvent = $stripeClient->events->retrieve($this->getEventId(), []);
            }
            else
            {
                try
                {
                    $stripeClient = $this->findStripeClientByOrder();
                    $this->stdEvent = $stripeClient->events->retrieve($this->getEventId(), []);
                }
                catch (\Exception $e)
                {
                    $this->stdEvent = $this->findEventAcrossAllAccounts();
                }
            }
        }

        $this->webhooksHelper->dispatchEvent($this->stdEvent, true);
    }

    public function shouldRetry()
    {
        // Failed events are retried on every run of the stripe_webhook_events_retry
        // cron job (scheduled every 15 minutes), giving up after 6 failed attempts.
        // The collection filter (getFailedEvents, retries < 6) enforces the same cap.
        return $this->getRetries() < 6;
    }

    protected function isForSingleOrder()
    {
        return (!empty($this->getOrderIncrementId()) && !$this->isForMultipleOrders());
    }

    protected function isForMultipleOrders()
    {
        $incrementId = $this->getOrderIncrementId();

        if (empty($incrementId))
            return false;

        if (strpos($incrementId, ",") === false)
            return false;

        return true;
    }

    protected function findStripeClientByOrder()
    {
        if ($this->isForSingleOrder())
        {
            $orderIncrementId = $this->getOrderIncrementId();
            $order = $this->orderHelper->loadOrderByIncrementId($orderIncrementId);

            if ($order && $order->getStoreId())
            {
                $this->config->reInitStripeFromStoreId($order->getStoreId());
                return $this->config->getStripeClient();
            }
        }
        else if ($this->isForMultipleOrders())
        {
            $orderIncrementIds = explode(",", $this->getOrderIncrementId());
            foreach ($orderIncrementIds as $orderIncrementId)
            {
                $order = $this->orderHelper->loadOrderByIncrementId($orderIncrementId);
                if ($order && $order->getStoreId())
                {
                    $this->config->reInitStripeFromStoreId($order->getStoreId());
                    return $this->config->getStripeClient();
                }
            }
        }

        throw new GenericException("Stripe client not found.");
    }

    protected function findEventAcrossAllAccounts()
    {
        $keys = $this->config->getAllAPIKeys();

        foreach ($keys as $secretKey => $publicKey)
        {
            $this->config->reInitStripeFromSecretKey($secretKey);

            try
            {
                return $this->config->getStripeClient()->events->retrieve($this->getEventId(), []);
            }
            catch (\Exception $e)
            {

            }
        }

        throw new GenericException("Event not found across any configured Stripe accounts.");
    }
}
