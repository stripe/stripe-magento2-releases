<?php

namespace StripeIntegration\Payments\Model;

use Magento\Framework\Exception\LocalizedException;
use StripeIntegration\Payments\Exception\GenericException;
use StripeIntegration\Payments\Exception\Exception;

class CheckoutSession extends \Magento\Framework\Model\AbstractModel
{
    private ?\StripeIntegration\Payments\Model\Stripe\Checkout\Session $stripeCheckoutSession = null;
    private $stripeCheckoutSessionFactory;
    private \StripeIntegration\Payments\Helper\Generic $paymentsHelper;
    private $customer;
    private $config;
    private $addressHelper;
    private $scopeConfig;
    private $quote = null;
    private $stripeCustomer;
    private $resourceModel;
    private $addressFactory;
    private $quoteHelper;
    private $orderHelper;
    private $checkoutSession;
    private $cartInfo;
    private $checkoutFlow;
    private $compare;
    private $convert;
    private $checkoutParamsFactory;
    private $checkoutSessionCollection;
    private $stripeCheckoutHelper;
    private $cache;
    private $couponFactory;
    private $customerUsageFactory;

    public function __construct(
        \StripeIntegration\Payments\Model\Stripe\Checkout\SessionFactory $stripeCheckoutSessionFactory,
        \StripeIntegration\Payments\Model\Cart\Info $cartInfo,
        \StripeIntegration\Payments\Model\Config $config,
        \StripeIntegration\Payments\Helper\Generic $paymentsHelper,
        \StripeIntegration\Payments\Helper\Address $addressHelper,
        \StripeIntegration\Payments\Helper\Quote $quoteHelper,
        \StripeIntegration\Payments\Helper\Order $orderHelper,
        \StripeIntegration\Payments\Helper\Convert $convert,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \StripeIntegration\Payments\Helper\Compare $compare,
        \StripeIntegration\Payments\Model\ResourceModel\CheckoutSession $resourceModel,
        \StripeIntegration\Payments\Model\Checkout\Flow $checkoutFlow,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Model\Context $context,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Framework\Registry $registry,
        \StripeIntegration\Payments\Model\Checkout\ParamsFactory $checkoutParamsFactory,
        \StripeIntegration\Payments\Model\ResourceModel\CheckoutSession\CollectionFactory $checkoutSessionCollectionFactory,
        \StripeIntegration\Payments\Helper\Stripe\CheckoutSession $stripeCheckoutHelper,
        \Magento\Framework\App\CacheInterface $cache,
        \Magento\SalesRule\Model\CouponFactory $couponFactory,
        \Magento\SalesRule\Model\Rule\CustomerFactory $customerUsageFactory,
        ?\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        ?\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->stripeCheckoutSessionFactory = $stripeCheckoutSessionFactory;
        $this->config = $config;
        $this->paymentsHelper = $paymentsHelper;
        $this->customer = $this->paymentsHelper->getCustomerModel();
        $this->addressHelper = $addressHelper;
        $this->scopeConfig = $scopeConfig;
        $this->convert = $convert;
        $this->compare = $compare;
        $this->resourceModel = $resourceModel;
        $this->checkoutFlow = $checkoutFlow;
        $this->addressFactory = $addressFactory;
        $this->quoteHelper = $quoteHelper;
        $this->orderHelper = $orderHelper;
        $this->checkoutSession = $checkoutSession;
        $this->cartInfo = $cartInfo;
        $this->checkoutParamsFactory = $checkoutParamsFactory;
        $this->checkoutSessionCollection = $checkoutSessionCollectionFactory->create();
        $this->stripeCheckoutHelper = $stripeCheckoutHelper;
        $this->cache = $cache;
        $this->couponFactory = $couponFactory;
        $this->customerUsageFactory = $customerUsageFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    protected function _construct()
    {
        $this->_init('StripeIntegration\Payments\Model\ResourceModel\CheckoutSession');
    }

    // Creates a session if one does not exist
    public function fromOrder($order)
    {
        $this->checkoutFlow->isCheckoutSessionRecreated = true;
        $this->quote = null;

        if (empty($order))
        {
            throw new GenericException('Invalid Stripe Checkout order.');
        }

        $this->unsetData();
        $existingRecord = $this->checkoutSessionCollection->getByQuoteId($order->getQuoteId());
        if ($existingRecord && $existingRecord->getId()) {
            $this->setData($existingRecord->getData());
        }

        $this->quote = $this->quoteHelper->loadQuoteById($order->getQuoteId());

        if (empty($this->quote) || empty($this->quote->getId()))
        {
            throw new GenericException('Could not find quote for order.');
        }

        $params = $this->getParamsFromOrder($order);
        $this->stripeCheckoutSession = $this->stripeCheckoutSessionFactory->create()->fromParams($params);
        $checkoutSessionObject = $this->stripeCheckoutSession->getStripeObject();

        $this->setQuoteId($this->quote->getId());
        $this->setOrderIncrementId($order->getIncrementId());
        $this->setCheckoutSessionId($checkoutSessionObject->id);
        $this->resourceModel->save($this);

        if (!$this->checkoutFlow->isNewOrderBeingPlaced)
        {
            $order->getPayment()->setAdditionalInformation('checkout_session_id', $checkoutSessionObject->id);
            $order->getPayment()->save();
        }

        $this->checkoutSession->setStripePaymentsCheckoutSessionId($checkoutSessionObject->id);
        $this->checkoutSession->setStripePaymentsCheckoutSessionURL($checkoutSessionObject->url);

        return $this;
    }

    private function createDummyCheckoutSessionFrom($quote)
    {
        $params = $this->getParamsFromQuote($quote);
        $stripeCheckoutSession = $this->stripeCheckoutSessionFactory->create()->fromParams($params);
        return $stripeCheckoutSession->getStripeObject();
    }

    public function getAvailablePaymentMethods($quote)
    {
        $methods = [];

        if (empty($quote) || empty($quote->getId()))
            return $methods;

        $checkoutSession = $this->createDummyCheckoutSessionFrom($quote);

        if (!empty($checkoutSession->payment_method_types))
            $methods = $checkoutSession->payment_method_types;

        return $methods;
    }

    public function getStripeObject()
    {
        if (empty($this->stripeCheckoutSession))
            return null;

        return $this->stripeCheckoutSession->getStripeObject();
    }

    public function getParamsFromOrder($order)
    {
        $checkoutParams = $this->checkoutParamsFactory->create();
        return $checkoutParams->fromOrder($order);
    }

    public function getParamsFromQuote($quote)
    {
        if (empty($quote))
            throw new GenericException("No quote specified for Checkout params.");

        $checkoutParams = $this->checkoutParamsFactory->create();
        return $checkoutParams->fromQuote($quote);
    }

    public function getOrder()
    {
        $orderIncrementId = $this->getOrderIncrementId();

        if (empty($orderIncrementId))
            return null;

        $order = $this->orderHelper->loadOrderByIncrementId($orderIncrementId);
        if ($order && $order->getId())
            return $order;

        return null;
    }

    public function isComplete()
    {
        if (!$this->getCheckoutSessionId() || !$this->stripeCheckoutSession)
            return false;

        $checkoutSession = $this->stripeCheckoutSession->getStripeObject();

        return ($checkoutSession && $checkoutSession->status == "complete");
    }

    public function cancelOrderAndReactivateQuote($orderComment)
    {
        if (!$this->getOrderIncrementId())
        {
            throw new Exception("No order was placed for this Stripe Checkout session.");
        }

        $order = $this->getOrder();
        if (!$order || !$order->getId())
        {
            throw new Exception("Could not load order for Stripe Checkout session.");
        }

        $this->orderHelper->cancelOrCloseOrder($order, $orderComment);
        $this->orderHelper->removeTransactions($order);
        $this->quoteHelper->reactivateQuote($order->getQuoteId(), $this->checkoutSession);

        $this->forgetOrder();
    }

    /**
     * Cancels a pending order (if it is still pending payment), restores its cart, and forgets
     * the local Checkout Session record.
     *
     * This is the shared logic for "the customer abandoned the payment" paths: the Stripe
     * Checkout cancel URL (Controller\Payment\Cancel) and the WCS back-button marker
     * (restoreWcsPendingOrder). Canceling through the canonical path restores Adobe Commerce
     * store credit (and other holds) via the order_cancel_after event; the cart is restored
     * without dispatching restore_quote so the store credit is released exactly once.
     *
     * @param string $orderIncrementId
     * @param \Magento\Framework\Phrase $orderComment
     * @return bool Whether the order was canceled.
     */
    public function cancelPendingOrderAndRestoreCart($orderIncrementId, $orderComment)
    {
        if (empty($orderIncrementId))
        {
            return false;
        }

        $order = $this->orderHelper->loadOrderByIncrementId($orderIncrementId);
        if (!$order || !$order->getId() || $order->getState() != \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
        {
            // The order is not pending (e.g. the payment completed) — nothing to cancel.
            return false;
        }

        // Cancel the pending order through the canonical path (restores store credit via
        // order_cancel_after) and clean up the payment transactions.
        $this->orderHelper->cancelOrCloseOrder($order, $orderComment);
        $this->orderHelper->removeTransactions($order);

        $checkoutSessionModel = $this->checkoutSessionCollection->getByOrderIncrementId($orderIncrementId);
        if ($checkoutSessionModel && $checkoutSessionModel->getId())
        {
            // Forget the local Checkout Session record so the canceled order cannot be resumed.
            $checkoutSessionModel->forgetOrder();
        }

        // Restore the cart only when the session is not already using a different quote (e.g. the
        // customer logged in after placing a guest order — that guest quote must not replace the
        // logged-in customer's cart). Quote ownership (guest vs. customer) is enforced inside
        // Helper\Quote::reactivateQuote().
        $currentQuote = $this->checkoutSession->getQuote();
        $orderQuoteId = $order->getQuoteId();

        if (!$currentQuote || !$currentQuote->getId() || (int)$currentQuote->getId() === (int)$orderQuoteId)
        {
            $this->quoteHelper->reactivateQuote($orderQuoteId, $this->checkoutSession);
        }

        return true;
    }

    /**
     * Cancels a pending Elements with Checkout Sessions (WCS) order and restores its quote,
     * when the customer returns to the checkout page without completing the payment (e.g.
     * pressing the back button from a redirect-based payment method's authorization page).
     *
     * The marker is set in the checkout session when the WCS order is placed (see
     * Model\PaymentMethod::pay()). This runs before the checkout page controller decides to
     * redirect to the (empty) cart, so the cart is restored and the store credit (and other
     * holds) are released by the order cancellation.
     *
     * @return void
     */
    public function restoreWcsPendingOrder()
    {
        $orderIncrementId = $this->checkoutSession->getStripePaymentsWcsRestoreOrder();
        if (empty($orderIncrementId))
        {
            return;
        }

        $this->checkoutSession->unsStripePaymentsWcsRestoreOrder();

        $this->cancelPendingOrderAndRestoreCart($orderIncrementId, __("The customer returned from the payment authorization page without completing the payment."));
    }

    public function forgetOrder()
    {
        $this->setOrderIncrementId(null)->save();
    }

    public function quoteIsDifferentFromOrder($quote)
    {
        $order = $this->getOrder();
        if (!$order)
        {
            throw new Exception("No order was placed for this Stripe Checkout session.");
        }

        // Check if the grand total is different between the quote and the order
        $this->cartInfo->setQuote($quote);
        if ($quote->getGrandTotal() != $order->getGrandTotal() && !$this->cartInfo->orderTotalIsDifferentThanQuoteTotal())
        {
            if ($order->getCouponCode() && $quote->getCouponCode() != $order->getCouponCode())
            {
                // Determine if coupon is globally exhausted (usage limit reached)
                $coupon = $this->couponFactory->create()->loadByCode($order->getCouponCode());
                $exhaustedGlobally = $coupon->getUsageLimit() && ($coupon->getTimesUsed() >= $coupon->getUsageLimit());

                // Determine if coupon is per customer exhausted (usage limit reached for the customer)
                if (!$order->getCustomerIsGuest() && $order->getCustomerId()) {
                    $customerUsage = $this->customerUsageFactory->create()->loadByCustomerRule($order->getCustomerId(), $coupon->getRuleId());
                    $exhaustedPerCustomer = $coupon->getUsagePerCustomer() && ($customerUsage->getTimesUsed() >= $coupon->getUsagePerCustomer());
                    // If the coupon is not globally exhausted and not per customer exhausted,
                    // the quote is different from the order
                    if (!$exhaustedGlobally && !$exhaustedPerCustomer) {
                        return true;
                    }
                } else {
                    // If the coupon is not globally exhausted when teh customer is not logged in,
                    // the quote is different from the order
                    if (!$exhaustedGlobally) {
                        return true;
                    }
                }
            }
            else
            {
                return true;
            }
        }

        // Check if the currency is different between the quote and the order
        if ($quote->getQuoteCurrencyCode() != $order->getOrderCurrencyCode())
        {
            return true;
        }

        // Check if the order is a guest order but the quote is a registered customer
        if ($order->getCustomerIsGuest() && $quote->getCustomerIsGuest() == 0)
        {
            return true;
        }

        // Check if the order is a registered customer but the quote is a guest
        if ($order->getCustomerIsGuest() == 0 && $quote->getCustomerIsGuest())
        {
            return true;
        }

        // Check if the email is different between the quote and the order
        if ($quote->getCustomerEmail() != $order->getCustomerEmail())
        {
            return true;
        }

        // Check if the quote is virtual but the order is not, and vice versa
        if ($quote->getIsVirtual() != $order->getIsVirtual())
        {
            return true;
        }

        if (!$quote->getIsVirtual())
        {
            // Check if the shipping address is different between the quote and the order
            $quoteShippingData = $this->addressHelper->filterAddressDataAndRemoveEmpty($quote->getShippingAddress()->getData());
            $orderShippingData = $this->addressHelper->filterAddressDataAndRemoveEmpty($order->getShippingAddress()->getData());
            if (count($quoteShippingData) != count($orderShippingData))
            {
                return true;
            }
            else if ($this->compare->isDifferent($quoteShippingData, $orderShippingData))
            {
                return true;
            }

            // Check if the shipping method has changed
            if ($quote->getShippingAddress()->getShippingMethod() != $order->getShippingMethod())
            {
                return true;
            }
        }

        // Check if the billing address is different between the quote and the order.
        $quoteBillingData = $this->addressHelper->filterAddressDataAndRemoveEmpty($quote->getBillingAddress()->getData());
        $orderBillingData = $this->addressHelper->filterAddressDataAndRemoveEmpty($order->getBillingAddress()->getData());
        if (count($quoteBillingData) != count($orderBillingData))
        {
            return true;
        }
        else if ($this->compare->isDifferent($quoteBillingData, $orderBillingData))
        {
            return true;
        }

        // Check if the items are different
        $quoteItems = $quote->getAllVisibleItems();
        $orderItems = $order->getAllVisibleItems();
        if (count($quoteItems) != count($orderItems))
        {
            return true;
        }

        foreach ($quoteItems as $quoteItem)
        {
            $found = false;
            foreach ($orderItems as $orderItem)
            {
                if ($quoteItem->getProductId() == $orderItem->getProductId())
                {
                    $found = true;
                    break;
                }
            }

            if (!$found)
            {
                return true;
            }
        }

        return false;
    }

    public function canCancelOrder()
    {
        $order = $this->getOrder();
        if (!$order)
        {
            throw new Exception("No order was placed for this Stripe Checkout session.");
        }

        if (!$this->getCheckoutSessionId())
        {
            throw new Exception("No Stripe Checkout session found.");
        }

        if ($order->getState() == \Magento\Sales\Model\Order::STATE_CANCELED)
            return false;

        if ($order->getState() == \Magento\Sales\Model\Order::STATE_COMPLETE)
            return false;

        if ($order->getState() == \Magento\Sales\Model\Order::STATE_CLOSED)
            return false;

        if (!$this->stripeCheckoutSession)
        {
            $this->stripeCheckoutSession = $this->stripeCheckoutSessionFactory->create()->load($this->getCheckoutSessionId());
        }

        if ($this->isComplete())
            return false;

        return true;
    }

    // ========== Adaptive Pricing (Elements mode) Session Lifecycle ==========

    /**
     * Compute a deterministic compact fingerprint for the quote.
     * Used to detect relevant changes between session creation and order placement.
     * Sorts items deterministically and includes all fields that affect
     * existing Checkout Params totals/line items.
     */
    public function getQuoteFingerprint($quote): string
    {
        $data = $this->getQuoteFingerprintData($quote);
        return hash('sha256', json_encode($data));
    }

    /**
     * Build the fingerprint data array for a quote.
     * Exposed so that fingerprint mismatches can be debugged by comparing
     * the stored and current data arrays field by field.
     */
    public function getQuoteFingerprintData($quote): array
    {
        return [
            'grand_total'            => (float)$quote->getGrandTotal(),
            'base_grand_total'       => (float)$quote->getBaseGrandTotal(),
            'currency'               => (string)$quote->getQuoteCurrencyCode(),
            'coupon_code'            => (string)$quote->getCouponCode(),
            'items'                  => $this->getItemsHash($quote),
            'customer_is_guest'      => (int)$quote->getCustomerIsGuest(),
            'is_virtual'             => (int)$quote->getIsVirtual(),
            'shipping_method'        => $quote->getIsVirtual() ? null : (string)$quote->getShippingAddress()->getShippingMethod(),
            'billing_address'        => $this->getAddressHash($quote->getBillingAddress()),
            'shipping_address'       => $quote->getIsVirtual() ? null : $this->getAddressHash($quote->getShippingAddress()),
            'payment_action'         => (string)$this->config->getPaymentAction(),
            'adaptive_pricing'       => (int)$this->config->isAdaptivePricingApplicable($quote),
        ];
    }

    /**
     * Compare two fingerprint data arrays and return a human-readable reason
     * for the first field that differs, or an empty string if they match.
     */
    public function compareFingerprintData(array $stored, array $current): string
    {
        foreach ($current as $key => $value)
        {
            if (!array_key_exists($key, $stored))
                return sprintf("fingerprint field '%s' was not stored", $key);

            $storedValue = $stored[$key];
            $currentValue = $current[$key];

            if (is_array($currentValue) || is_array($storedValue))
            {
                $storedJson = json_encode($storedValue);
                $currentJson = json_encode($currentValue);
                if ($storedJson !== $currentJson)
                    return sprintf("fingerprint field '%s' changed: stored=%s, current=%s", $key, $storedJson, $currentJson);
            }
            else
            {
                if ($storedValue !== $currentValue)
                    return sprintf("fingerprint field '%s' changed: stored=%s, current=%s", $key, $storedValue, $currentValue);
            }
        }

        // Check for keys that were stored but are no longer present
        foreach ($stored as $key => $value)
        {
            if (!array_key_exists($key, $current))
                return sprintf("fingerprint field '%s' was stored but is no longer present", $key);
        }

        return '';
    }

    private function getItemsHash($quote): array
    {
        $hash = [];
        foreach ($quote->getAllVisibleItems() as $item) {
            $hash[] = [
                'item_id'           => (int)$item->getItemId(),
                'product_id'        => (int)$item->getProductId(),
                'sku'               => (string)$item->getSku(),
                'qty'               => (float)$item->getQty(),
                'price'             => (float)$item->getPrice(),
                'row_total'         => (float)$item->getRowTotal(),
                'base_row_total'    => (float)$item->getBaseRowTotal(),
                'discount_amount'   => (float)$item->getDiscountAmount(),
                'tax_amount'        => (float)$item->getTaxAmount(),
                'is_virtual'        => (int)$item->getIsVirtual(),
            ];
        }
        // Sort deterministically by item_id for stable hashing
        usort($hash, function ($a, $b) {
            return $a['item_id'] - $b['item_id'];
        });
        return $hash;
    }

    private function getAddressHash($address): ?array
    {
        if (!$address) {
            return null;
        }
        $data = [
            'firstname' => (string)$address->getFirstname(),
            'lastname'  => (string)$address->getLastname(),
            'street'    => implode("\n", (array)$address->getStreet()),
            'city'      => (string)$address->getCity(),
            'region'    => (string)$address->getRegion(),
            'postcode'  => (string)$address->getPostcode(),
            'country'   => (string)$address->getCountryId(),
        ];
        // Include even when address ID is absent (pre-order)
        return $data;
    }

    /**
     * Create or reuse a Checkout Session for the given quote.
     *
     * Multiple sessions may be created per quote; no locking is used.
     *
     * @return \Stripe\Checkout\Session|null
     */
    public function createOrReuseAdaptiveSession($quote, $contactDetails = null)
    {
        if (!$quote || !$quote->getId()) {
            return null;
        }

        $quoteId = $quote->getId();

        // Reserve order ID to be used with metadata
        if (!$quote->getReservedOrderId()) {
            $quote->reserveOrderId();
        }

        $reservedOrderId = $quote->getReservedOrderId();
        $staleRow = null;

        // 1. Build the full session params FIRST. From these we derive both the
        //    contact hash (raw frontend data) and the params fingerprint (everything
        //    that goes into the session). The fingerprint is used for reuse decisions.
        $checkoutParams = $this->checkoutParamsFactory->create();
        $params = $checkoutParams->fromQuoteForAdaptive($quote, $contactDetails);
        $params['client_reference_id'] = $reservedOrderId;

        // Use the reserved order increment ID for the description instead of the
        // quote ID, so that charges appear as "Order #123456 by Jane Doe" rather
        // than "Cart 456 by Jane Doe".
        if (isset($params['payment_intent_data']) && is_array($params['payment_intent_data']))
        {
            $params['payment_intent_data']['description'] = $this->quoteHelper->getOrderDescription($quote, $reservedOrderId);
        }

        // Compute params fingerprint: hash of the entire params array, excluding
        // client_reference_id which may vary between requests.
        // When a Stripe customer ID is used (instead of customer_email), the email
        // is not in the params — it's on the Stripe customer object. Inject it so
        // that changing the email invalidates the fingerprint and forces a session
        // re-creation with the updated customer email.
        $fingerprintParams = $params;
        unset($fingerprintParams['client_reference_id']);
        if (!empty($params['customer']) && empty($params['customer_email']))
        {
            $email = null;
            if (!empty($contactDetails['email']))
                $email = trim($contactDetails['email']);
            else if ($quote->getCustomerEmail())
                $email = $quote->getCustomerEmail();
            if ($email)
                $fingerprintParams['_customer_email'] = $email;
        }
        $paramsFingerprint = hash('sha256', json_encode($fingerprintParams));

        // Contact hash from raw frontend data (used for the extra contact check)
        $contactHash = is_array($contactDetails) ? hash('sha256', json_encode($contactDetails)) : null;

        // 2. Check for existing reusable session
        $existing = $this->checkoutSessionCollection->getByQuoteId($quoteId);

        if ($existing && $existing->getId()) {
            $stripeSessionModel = null;
            $stripeSession = null;

            try {
                $stripeSessionModel = $this->stripeCheckoutSessionFactory->create()
                    ->fromSessionId($existing->getCheckoutSessionId());
                /** @var \Stripe\Checkout\Session|null $stripeSession */
                $stripeSession = $stripeSessionModel->getStripeObject();
            } catch (\Stripe\Exception\InvalidRequestException $e) {
                // confirmed not-found / expired on Stripe — schedule for deletion
                $staleRow = $existing;
                $existing = null;
            } catch (\Exception $e) {
                // network / auth / rate-limit / unknown — preserve local row, bail
                $this->paymentsHelper->logError(
                    "Failed to verify existing session for quote $quoteId: " . $e->getMessage()
                );
                return null;
            }

            if ($existing && $stripeSession) {
                if ($stripeSession->status === 'open') {
                    // Compare the cached params fingerprint against the current one.
                    // Only reuse when the full params are identical — this covers
                    // line items, totals, contacts, addresses, payment options etc.
                    $storedFingerprint = $this->stripeCheckoutHelper->getStoredFingerprint($stripeSession->id);

                    if ($storedFingerprint === $paramsFingerprint) {
                        if (!empty($stripeSession->client_secret)
                            && $stripeSession->ui_mode === 'elements') {
                            $this->setData($existing->getData());
                            $this->stripeCheckoutSession = $stripeSessionModel;
                            $this->checkoutSession->setStripePaymentsCheckoutSessionId($stripeSession->id);
                            $this->checkoutSession->setStripePaymentsCheckoutSessionURL($stripeSession->url);
                            return $stripeSession;
                        }
                        // Fall through to expire + recreate
                    }

                    // Open but stale fingerprint or wrong mode — must expire before replace
                    try {
                        $stripeSessionModel->expire();
                    } catch (\Exception $e) {
                        $this->paymentsHelper->logError(
                            "Failed to expire stale session for quote $quoteId: " . $e->getMessage()
                        );
                        return null;
                    }
                }
                // status is 'complete' or 'expired' — schedule for deletion
                $staleRow = $existing;
            }
        }

        // 3. Create via Stripe API wrapper
        $stripeSessionModel = $this->stripeCheckoutSessionFactory->create()->fromParams($params);
        $stripeSession = $stripeSessionModel->getStripeObject();

        if (!$stripeSession || !$stripeSession->id) {
            return null;
        }

        // 4. Cache fingerprint + contact hash + quote fingerprint for reuse checks
        $quoteFingerprintData = $this->getQuoteFingerprintData($quote);
        $quoteFingerprint = hash('sha256', json_encode($quoteFingerprintData));
        $this->stripeCheckoutHelper->saveStoredFingerprint($stripeSession->id, $paramsFingerprint, $contactHash, $quoteFingerprint, $quoteFingerprintData);

        // 5. All DB writes deferred until after Stripe API success
        $this->quoteHelper->saveQuote($quote);

        if ($staleRow) {
            $staleRow->delete();
        }

        $this->setQuoteId($quoteId);
        $this->setOrderIncrementId($reservedOrderId);
        $this->setCheckoutSessionId($stripeSession->id);

        $this->resourceModel->save($this);

        $this->checkoutSession->setStripePaymentsCheckoutSessionId($stripeSession->id);
        $this->checkoutSession->setStripePaymentsCheckoutSessionURL($stripeSession->url);

        $this->stripeCheckoutSession = $stripeSessionModel;
        return $stripeSession;
    }

    /**
     * Expire an adaptive (Elements mode) session for a given quote ID.
     *
     * Distinguishes confirmed-gone/terminal states (safe to delete local row)
     * from transient or unknown errors (preserve local row, log).
     *
     * Safe-to-delete indicators (in priority order):
     * 1. HTTP 404 status
     * 2. Stripe error code `resource_missing`
     * 3. Stripe error code `checkout_session_not_open` or similar terminal code
     * 4. Message substring match (case-insensitive fallback)
     *    - "No such checkout.session"
     *    - "No such checkout_session"
     *    - "already expired"
     *    - "is not open"
     */
    public function expireAdaptiveSession($quoteId)
    {
        $sessionModel = $this->checkoutSessionCollection->getByQuoteId($quoteId);
        if (!$sessionModel || !$sessionModel->getId()) {
            return;
        }

        $sessionId = $sessionModel->getCheckoutSessionId();
        try {
            $stripeSession = $this->stripeCheckoutSessionFactory->create()
                ->fromSessionId($sessionId);
            $stripeSession->expire();
            // Successfully expired on Stripe
            $sessionModel->delete();
        } catch (\Stripe\Exception\InvalidRequestException $e) {
            $httpStatus = $e->getHttpStatus();
            $stripeCode = $e->getStripeCode();
            $message = $e->getMessage();

            // Check safe-to-delete conditions in priority order
            $safeToDelete = ($httpStatus === 404)
                || ($stripeCode === 'resource_missing')
                || ($stripeCode === 'checkout_session_not_open')
                || (stripos($message, 'No such checkout.session') !== false)
                || (stripos($message, 'No such checkout_session') !== false)
                || (stripos($message, 'already expired') !== false)
                || (stripos($message, 'is not open') !== false);

            if ($safeToDelete) {
                $sessionModel->delete();
            } else {
                $this->paymentsHelper->logError(
                    "Failed to expire Checkout Session $sessionId: "
                    . "httpStatus=$httpStatus stripeCode=$stripeCode message=" . $message
                );
            }
        } catch (\Exception $e) {
            // Unknown failure -- preserve local row and log
            $this->paymentsHelper->logError(
                "Failed to expire Checkout Session $sessionId: " . get_class($e)
                . ' ' . $e->getMessage()
            );
        }
    }

}
