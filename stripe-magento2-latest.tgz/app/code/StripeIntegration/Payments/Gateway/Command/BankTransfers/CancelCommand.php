<?php

namespace StripeIntegration\Payments\Gateway\Command\BankTransfers;

use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Gateway\CommandInterface;

class CancelCommand implements CommandInterface
{
    private $config;
    private $areaCodeHelper;
    private $paymentIntentHelper;

    public function __construct(
        \StripeIntegration\Payments\Model\Config $config,
        \StripeIntegration\Payments\Helper\AreaCode $areaCodeHelper,
        \StripeIntegration\Payments\Helper\PaymentIntent $paymentIntentHelper
    ) {
        $this->config = $config;
        $this->areaCodeHelper = $areaCodeHelper;
        $this->paymentIntentHelper = $paymentIntentHelper;
    }

    public function execute(array $commandSubject): void
    {
        $payment = $commandSubject['payment']->getPayment();
        $stripeToken = $payment->getAdditionalInformation('token');

        // Only run the code when the bank transfer is created from the frontend
        // For bank transfers that are created in the admin, the invoice cancellation kicks in, and does not require
        // any specific actions from this command. This could change if cancellation from admin will be implemented.
        if ($stripeToken) {
            // Throw exception if there is no payment record on the payment.
            $paymentIntentId = $payment->getLastTransId();
            if (!$paymentIntentId) {
                throw new LocalizedException(__('The payment cannot be cancelled: No transactions registered on the payment.'));
            }

            // Load the payment intent to check cancel viability
            $paymentIntent = $this->config->getStripeClient()->paymentIntents->retrieve($paymentIntentId);

            // This hits when the payment intent is canceled from the Stripe Dashboard, so we don't have
            // to cancel the payment intent ourselves, and we continue with the cancel process for the Magento order.
            if ($this->paymentIntentHelper->isCanceled($paymentIntent)) {
                return;
            }

            if (!$this->paymentIntentHelper->canCancel($paymentIntent)) {
                throw new LocalizedException(__('The payment cannot be cancelled.'));
            }

            // The cancel process will be started by cancelling the payment intent. This will trigger the Payment intent
            // cancelling webhook handler, which will cancel the order.
            $cancellationReason = [
                "cancellation_reason" => "abandoned"
            ];

            // If cancellation is done from admin, set the reason as requested by the customer
            if ($this->areaCodeHelper->isAdmin()) {
                $cancellationReason = [
                    "cancellation_reason" => "requested_by_customer"
                ];
            }

            $this->config->getStripeClient()->paymentIntents->cancel($paymentIntentId, $cancellationReason);
        }
    }
}
