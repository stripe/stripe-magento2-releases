<?php

namespace StripeIntegration\Payments\Block\Checkout\Onepage\Success;

use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Model\Order;
use StripeIntegration\Payments\Helper\PaymentIntent as PaymentIntentHelper;
use StripeIntegration\Payments\Helper\PendingPaymentAction;
use StripeIntegration\Payments\Helper\Stripe\CheckoutSession as StripeCheckoutSession;
use StripeIntegration\Payments\Model\Stripe\PaymentIntentFactory;
use StripeIntegration\Payments\Model\Stripe\SetupIntentFactory;

/**
 * Displays the Stripe hosted page which the customer needs in order to complete a delayed
 * notification payment: microdeposit verification for ACH Direct Debit, or a voucher (Boleto,
 * OXXO, Konbini, Multibanco) which has to be paid for the order to be settled.
 */
class PendingPayment extends Template
{
    private $checkoutSession;
    private $pendingPaymentActionHelper;
    private $paymentIntentHelper;
    private $stripeCheckoutSessionHelper;
    private $stripePaymentIntentFactory;
    private $stripeSetupIntentFactory;
    private $pendingPaymentAction = null;
    private $resolved = false;

    public function __construct(
        Context $context,
        CheckoutSession $checkoutSession,
        PendingPaymentAction $pendingPaymentActionHelper,
        PaymentIntentHelper $paymentIntentHelper,
        StripeCheckoutSession $stripeCheckoutSessionHelper,
        PaymentIntentFactory $stripePaymentIntentFactory,
        SetupIntentFactory $stripeSetupIntentFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->checkoutSession = $checkoutSession;
        $this->pendingPaymentActionHelper = $pendingPaymentActionHelper;
        $this->paymentIntentHelper = $paymentIntentHelper;
        $this->stripeCheckoutSessionHelper = $stripeCheckoutSessionHelper;
        $this->stripePaymentIntentFactory = $stripePaymentIntentFactory;
        $this->stripeSetupIntentFactory = $stripeSetupIntentFactory;
    }

    /**
     * The recorded action is only displayed while Stripe still considers the payment to be pending.
     * The intent carries its next action only while the customer has not acted on it yet, so a
     * voucher which has already been paid, or microdeposits which have already been verified, will
     * not produce a notice even though the URL remains recorded on the order payment.
     *
     * @return array|null ['type' => string, 'url' => string]
     */
    public function getPendingPaymentAction()
    {
        if ($this->resolved)
        {
            return $this->pendingPaymentAction;
        }

        $this->resolved = true;

        $order = $this->checkoutSession->getLastRealOrder();

        if (empty($order) || !$order->getId() || !$order->getPayment())
        {
            return $this->pendingPaymentAction = null;
        }

        $payment = $order->getPayment();
        $action = $this->pendingPaymentActionHelper->getFromPayment($payment);

        if (empty($action))
        {
            return $this->pendingPaymentAction = null;
        }

        $intent = $this->getLiveIntent($payment, $action['type']);

        if (!empty($intent))
        {
            // Stripe is the source of truth: the intent no longer carries a next action once the
            // customer has completed it.
            if (!$this->paymentIntentHelper->requiresOfflineAction($intent))
            {
                return $this->pendingPaymentAction = null;
            }
        }
        else if (!$this->isPendingPayment($order))
        {
            // Stripe could not be reached; only trust the recorded action while the order is still
            // awaiting payment.
            return $this->pendingPaymentAction = null;
        }

        return $this->pendingPaymentAction = $action;
    }

    /**
     * @return string|null
     */
    public function getPendingPaymentUrl()
    {
        $action = $this->getPendingPaymentAction();

        return $action['url'] ?? null;
    }

    /**
     * @return string|null
     */
    public function getPendingPaymentType()
    {
        $action = $this->getPendingPaymentAction();

        return $action['type'] ?? null;
    }

    /**
     * The notice shown above the link, matching the type of pending payment.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getMessage()
    {
        if ($this->getPendingPaymentType() == PendingPaymentAction::TYPE_MICRODEPOSITS)
        {
            return __("Your bank account is pending microdeposit verification. Please verify the two small deposits that appear on your bank statement to complete this payment.");
        }

        return __("Your order is pending payment. Please complete the payment using the voucher below.");
    }

    /**
     * The link label, kept consistent with the order email's payment details.
     *
     * @return \Magento\Framework\Phrase
     */
    public function getLinkLabel()
    {
        if ($this->getPendingPaymentType() == PendingPaymentAction::TYPE_MICRODEPOSITS)
        {
            return __("Verify your bank account");
        }

        return __("View voucher");
    }

    /**
     * The live Stripe intent which carries the pending action: the SetupIntent for subscription
     * microdeposits, otherwise the PaymentIntent (retrieved through the Checkout Session in the
     * EwCS flow, where no transaction id is stored yet).
     *
     * @param \Magento\Payment\Model\InfoInterface|\Magento\Sales\Model\Order\Payment $payment
     * @param string $type
     * @return \Stripe\PaymentIntent|\Stripe\SetupIntent|null
     */
    private function getLiveIntent($payment, $type)
    {
        try
        {
            if ($type == PendingPaymentAction::TYPE_MICRODEPOSITS)
            {
                $setupIntentId = $payment->getAdditionalInformation('pending_microdeposit_si_id');

                if (!empty($setupIntentId))
                {
                    return $this->stripeSetupIntentFactory->create()
                        ->fromSetupIntentId($setupIntentId)
                        ->getStripeObject();
                }
            }

            $transactionId = $this->stripeCheckoutSessionHelper->getLastTransactionId($payment);

            if (!empty($transactionId) && strpos($transactionId, 'seti_') === 0)
            {
                return $this->stripeSetupIntentFactory->create()
                    ->fromSetupIntentId($transactionId)
                    ->getStripeObject();
            }

            if (!empty($transactionId) && strpos($transactionId, 'pi_') === 0)
            {
                return $this->stripePaymentIntentFactory->create()
                    ->fromPaymentIntentId($transactionId)
                    ->getStripeObject();
            }
        }
        catch (\Exception $e)
        {
            // Fall back to the recorded action below
        }

        return null;
    }

    /**
     * @param Order $order
     * @return bool
     */
    private function isPendingPayment($order)
    {
        return $order->getState() == Order::STATE_PENDING_PAYMENT;
    }
}
