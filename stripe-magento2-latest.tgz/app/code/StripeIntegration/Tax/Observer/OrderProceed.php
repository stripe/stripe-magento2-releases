<?php

namespace StripeIntegration\Tax\Observer;

use \Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Event\Observer;
use StripeIntegration\Tax\Helper\Exception;
use StripeIntegration\Tax\Model\StripeTax;
use StripeIntegration\Tax\Model\TaxFlow;

class OrderProceed implements ObserverInterface
{
    private $taxFlow;
    private $stripeTax;
    private $exceptionHelper;

    public function __construct(
        TaxFlow $taxFlow,
        StripeTax $stripeTax,
        Exception $exceptionHelper
    ) {
        $this->taxFlow = $taxFlow;
        $this->stripeTax = $stripeTax;
        $this->exceptionHelper = $exceptionHelper;
    }

    public function execute(Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        // Check only if Tax enabled and order is new
        if ($this->stripeTax->isEnabled() && !$order->getId()) {
            $addressId = $this->resolveQuoteAddressId($order);
            if (!$this->taxFlow->canAddressProceed($addressId)) {
                $this->exceptionHelper->throwTaxCalculationException($addressId);
            }
        }
    }

    /**
     * Get the address ID of the last item in the order
     *
     * @param $order
     * @return int|null
     */
    private function resolveQuoteAddressId($order)
    {
        $quote = $order->getQuote();
        if (!$quote || !$quote->getIsMultiShipping()) {
            return null; // single-address checkout: fall back to global flags
        }

        $items = $order->getItems();
        $item = array_pop($items);

        if (!$item) {
            return null;
        }

        // Go through all the addresses and if the order item has a corresponding address item,
        // return the address ID
        foreach ($quote->getAllShippingAddresses() as $address) {
            foreach ($address->getAllItems() as $addressItem) {
                if ($addressItem->getQuoteItemId() == $item->getQuoteItemId()) {
                    return (int)$address->getId();
                }
            }
        }

        // If the order has virtual items, return the billing address ID
        if ($quote->hasVirtualItems()) {
            return (int)$quote->getBillingAddress()->getId();
        }

        return null;
    }
}
