<?php

namespace StripeIntegration\Tax\Model;

class TaxFlow
{
    public $orderTaxCalculationSuccessful = false;
    public $orderMappingIssues = false;
    public $orderItemCalculationIssues = false;
    public $invoiceTaxCalculationSuccessful = false;
    public $invoiceTransactionSuccessful = false;
    public $reversalSavedToDatabase = false;
    public $reversalCreatedInStripe = false;
    public $reversalAttemptedInStripe = false;

    public $isNewOrderBeingPlaced = false;
    public $customerInvalidLocation = false;

    public $addressResults = [];

    public function canOrderProceed()
    {
        return $this->orderTaxCalculationSuccessful &&
            !$this->orderMappingIssues &&
            !$this->orderItemCalculationIssues;
    }

    public function canInvoiceProceed()
    {
        return $this->invoiceTaxCalculationSuccessful && $this->invoiceTransactionSuccessful;
    }

    public function reversalFailedInStripe()
    {
        return $this->reversalAttemptedInStripe && !$this->reversalCreatedInStripe;
    }

    public function reversalSucceededInStripe()
    {
        return $this->reversalAttemptedInStripe && $this->reversalCreatedInStripe && !$this->reversalSavedToDatabase;
    }

    /**
     * Create a snapshot for the current address so that we can check against it
     * when determining if order can proceed
     *
     * @param $addressId
     * @return void
     */
    public function recordAddressResult($addressId)
    {
        if ($addressId === null) {
            return;
        }
        $this->addressResults[$addressId] = [
            'successful' => $this->orderTaxCalculationSuccessful,
            'invalidLocation' => $this->customerInvalidLocation,
            'mappingIssues' => $this->orderMappingIssues,
            'itemIssues' => $this->orderItemCalculationIssues,
        ];
    }

    public function canAddressProceed($addressId)
    {
        if ($addressId === null || !isset($this->addressResults[$addressId])) {
            return $this->canOrderProceed();
        }

        $result = $this->addressResults[$addressId];

        return $result['successful'] && !$result['mappingIssues'] && !$result['itemIssues'];
    }

    public function isCustomerInvalidLocation($addressId)
    {
        if ($addressId === null || !isset($this->addressResults[$addressId])) {
            return $this->customerInvalidLocation;
        }

        $result = $this->addressResults[$addressId];

        return $result['invalidLocation'];
    }
}
